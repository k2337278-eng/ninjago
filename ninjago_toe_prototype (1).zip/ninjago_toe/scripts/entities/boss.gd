class_name Boss
extends Enemy
## Multi-phase boss. Attacks: slam, charge, volley, summon, combo, staffspin, rain.
## Telegraphs (red glow / warning discs), super armor, and a weak-point window:
## after slam/charge/staffspin the boss is "exhausted" (yellow glow): +60% damage and
## it can be stunned. Phase thresholds trigger invulnerable transitions + minions.

signal phase_changed(boss, n)
signal summon_requested(boss, kind, count)

var title: Array = ["Boss", "زعيم"]
var attacks: Array = []
var phase_marks: Array = []
var phase := 1
var act: Dictionary = {}
var act_t := 0.0
var cd := 2.0
var volley_ab: Dictionary = {}
var base_speed := 4.0
var minion_kind := "grunt"
var _tick := 0.0

static func build(id: String) -> Boss:
	var b := Boss.new()
	b.kind = "boss"
	b.team = "enemy"
	b.char_id = "boss_" + id
	b.poise = 999.0
	var col := Color(0.7, 0.7, 0.75)
	match id:
		"warden":
			b.title = ["Arena Warden", "حارس الساحة"]
			b.max_health = 520.0
			b.move_speed = 3.6
			b.atk_damage = 18.0
			b.xp_reward = 250
			b.coin_reward = 80
			b.attacks = [["slam", "charge"], ["slam", "charge", "summon", "volley"]]
			b.phase_marks = [0.5]
			b.minion_kind = "grunt"
			b.rig_cfg = {"suit": Color(0.4, 0.38, 0.42), "style": "bare", "hair": Color(0.2, 0.2, 0.22), "hat": Color(0.3, 0.3, 0.35), "scale": 1.7}
		"warlord":
			b.title = ["Anacondrai Warlord", "قائد الأناكوندراي"]
			b.max_health = 700.0
			b.move_speed = 4.2
			b.atk_damage = 20.0
			b.xp_reward = 350
			b.coin_reward = 120
			b.attacks = [["charge", "volley", "slam"], ["charge", "volley", "slam", "summon", "rain"]]
			b.phase_marks = [0.55]
			b.minion_kind = "serpent"
			col = Color(0.3, 0.8, 0.2)
			b.rig_cfg = {"suit": Color(0.25, 0.1, 0.35), "style": "bare", "hat": Color(0.15, 0.4, 0.15), "scale": 1.6}
		"champion":
			b.title = ["Tournament Champion", "بطل البطولة"]
			b.max_health = 600.0
			b.move_speed = 5.2
			b.atk_damage = 16.0
			b.xp_reward = 300
			b.coin_reward = 100
			b.attacks = [["combo", "volley", "charge"], ["combo", "volley", "charge", "staffspin"]]
			b.phase_marks = [0.5]
			b.minion_kind = "elite"
			col = Color(1.0, 0.8, 0.2)
			b.rig_cfg = {"suit": Color(0.9, 0.7, 0.1), "style": "ninja", "scale": 1.35}
		"chen":
			b.title = ["Master Chen", "الماستر تشِن"]
			b.max_health = 1500.0
			b.move_speed = 4.0
			b.atk_damage = 22.0
			b.xp_reward = 800
			b.coin_reward = 300
			b.attacks = [["slam", "volley", "staffspin"],
				["slam", "volley", "staffspin", "summon", "charge"],
				["slam", "volley", "staffspin", "summon", "rain", "charge"]]
			b.phase_marks = [0.66, 0.33]
			b.minion_kind = "serpent"
			col = Color(0.7, 0.2, 0.9)
			b.rig_cfg = {"suit": Color(0.35, 0.05, 0.1), "style": "bare", "robe": Color(0.3, 0.0, 0.35), "hat": Color(0.2, 0.0, 0.2), "scale": 1.7}
	b.rig_cfg["weapon"] = {"warden": "hammer", "warlord": "spear", "champion": "sword_gold", "chen": "staff"}.get(id, "")
	b.health = b.max_health
	b.base_speed = b.move_speed
	b.display_name = Loc.pick(b.title)
	b.volley_ab = {"kind": "projectile", "damage": b.atk_damage * 0.6, "range": 18.0, "speed": 14.0,
		"radius": 0.9, "splash": 0.0, "pierce": false, "color": col, "status": "", "sfx": "energy", "cooldown": 1.0}
	return b

func take_damage(amount: float, src: Node3D, kb := 6.0, stun := 0.0, ignore_block := false) -> bool:
	var weak := statuses.has("weak")
	if weak:
		amount *= 1.6
	var ok := super.take_damage(amount, src, kb * 0.3, stun if weak else 0.0, ignore_block)
	if ok and state != S.DEAD:
		_check_phase()
	return ok

func _check_phase() -> void:
	if phase - 1 >= phase_marks.size():
		return
	if health / max_health <= float(phase_marks[phase - 1]):
		phase += 1
		act = {}
		_set_state(S.IDLE)
		invuln = 1.3
		move_speed = base_speed * (1.0 + 0.12 * (phase - 1))
		cd = 1.8
		rig.flash_t = 0.4
		Effects.ring(self, global_position, 7.0, Color(1, 1, 0.4))
		Effects.shake(self, 0.4)
		phase_changed.emit(self, phase)
		summon_requested.emit(self, minion_kind, 2)

func think(delta: float) -> void:
	move_input = Vector3.ZERO
	aim_dir = Vector3.ZERO
	cd -= delta
	if target == null or not is_instance_valid(target) or target.state == S.DEAD or target.downed:
		target = nearest_foe(global_position)
	if not act.is_empty():
		if state != S.ATTACK:
			act = {}
		else:
			_run_act(delta)
			return
	if target == null or state != S.IDLE:
		return
	var to := target.global_position - global_position
	to.y = 0.0
	var dist := to.length()
	if dist < 0.01:
		return
	aim_dir = to / dist
	if dist > 3.2:
		move_input = aim_dir
	if cd <= 0.0:
		_start_act(_choose(dist))

func _choose(dist: float) -> String:
	var list: Array = attacks[mini(phase, attacks.size()) - 1]
	var far: Array = []
	for a in list:
		if a == "charge" or a == "volley" or a == "rain":
			far.append(a)
	if dist > 6.0 and not far.is_empty():
		return far[randi() % far.size()]
	return list[randi() % list.size()]

func _start_act(n: String) -> void:
	act = {"name": n}
	act_t = 0.0
	_tick = 0.0
	if aim_dir.length() > 0.1:
		face_dir = aim_dir
	atk = {"hit": 999.0, "dur": 999.0, "combo": false, "anim": "idle"}
	atk_hit_done = true
	_set_state(S.ATTACK)
	var dur := 1.4
	match n:
		"slam":
			rig.play("heavy", 1.4)
			rig.warn_t = 1.0
			Effects.warn_ring(self, global_position, 5.5, 0.9)
			dur = 1.6
		"charge":
			rig.play("enemy_atk", 1.0)
			rig.warn_t = 0.8
			dur = 2.0
		"volley":
			rig.play("cast", 1.3)
			dur = 1.5
		"summon":
			rig.play("cast", 1.2)
			dur = 1.4
		"combo":
			rig.play("enemy_atk", 0.5)
			dur = 1.5
		"staffspin":
			rig.play("spin", 1.4)
			rig.warn_t = 0.4
			dur = 1.6
		"rain":
			rig.play("cast", 1.6)
			dur = 2.8
	act["dur"] = dur

func _aoe_damage(pos: Vector3, r: float, dmg: float, kb: float) -> void:
	for n in get_tree().get_nodes_in_group("fighters"):
		var t := n as Fighter
		if t == null or t.team == team or t.state == S.DEAD:
			continue
		if Vector2(t.global_position.x - pos.x, t.global_position.z - pos.z).length() <= r:
			t.take_damage(dmg, self, kb)

func _run_act(delta: float) -> void:
	act_t += delta
	var n: String = act["name"]
	if act_t < 0.6 and target != null and is_instance_valid(target):
		var to := target.global_position - global_position
		to.y = 0.0
		if to.length() > 0.1:
			face_dir = to.normalized()
	match n:
		"slam":
			if act_t >= 0.9 and not act.has("hit"):
				act["hit"] = true
				Effects.ring(self, global_position, 5.5, Color(1, 0.3, 0.1))
				Effects.shake(self, 0.5)
				Sfx.play("quake")
				_aoe_damage(global_position, 5.5, atk_damage * 1.2, 11.0)
		"charge":
			if act_t >= 0.8 and act_t < 1.4:
				knock = face_dir * 15.0
				_tick -= delta
				if _tick <= 0.0:
					_tick = 0.15
					melee(atk_damage, 2.0, 360.0, 9.0)
		"volley":
			if act_t >= 0.5 and not act.has("hit"):
				act["hit"] = true
				var base := face_dir
				for ang in [-0.3, 0.0, 0.3]:
					face_dir = base.rotated(Vector3.UP, ang)
					Projectile.fire(self, volley_ab)
				face_dir = base
		"summon":
			if act_t >= 0.6 and not act.has("hit"):
				act["hit"] = true
				summon_requested.emit(self, minion_kind, 2 if phase < 3 else 3)
		"combo":
			var i := 0
			for t in [0.3, 0.65, 1.0]:
				var key := "h%d" % i
				i += 1
				if act_t >= t and not act.has(key):
					act[key] = true
					melee(atk_damage * 0.7, 2.8, 130.0, 6.0)
					Sfx.play("swing")
		"staffspin":
			_tick -= delta
			if act_t > 0.3 and act_t < 1.5 and _tick <= 0.0:
				_tick = 0.3
				melee(atk_damage * 0.5, 3.4, 360.0, 7.0)
		"rain":
			if act_t >= 0.4 and not act.has("hit"):
				act["hit"] = true
				var c := target.global_position if target != null and is_instance_valid(target) else global_position
				for k in 5:
					var p := c + Vector3(randf_range(-5.0, 5.0), 0.0, randf_range(-5.0, 5.0))
					Effects.warn_ring(self, p, 2.4, 1.0)
					get_tree().create_timer(1.0).timeout.connect(func():
						if is_instance_valid(self) and state != S.DEAD:
							Effects.burst(self, p + Vector3(0, 0.5, 0), Color(1, 0.3, 0.1), 20, 6.0)
							_aoe_damage(p, 2.4, atk_damage * 0.9, 8.0))
	if act_t >= float(act["dur"]):
		act = {}
		_set_state(S.IDLE)
		cd = randf_range(1.2, 2.2) * (0.8 if phase > 1 else 1.0)
		if n == "slam" or n == "charge" or n == "staffspin":
			statuses["weak"] = 2.2
