# Ninjago: Tournament of Elements - Godot 4 prototype (Chapter 1 vertical slice)

Original geometry/sounds only (no LEGO/Ninjago assets). Unofficial fan prototype.

## Run
1. Install Godot 4.3+ (free, godotengine.org). Open `project.godot` (Import), press F5.
2. Desktop controls: WASD move, mouse-drag camera, J light, K heavy, Space jump,
   Q Spinjitzu, E elemental power, Shift dodge, L block (hold), F interact, Esc pause.
   The mouse also drives the on-screen touch controls (touch emulation is enabled).
3. Tests (needs Godot): `godot --headless --path . -s tests/test_data.gd`
   Static checks (Python only): `python3 tests/static_check.py`

## Build the APK
1. Editor > Manage Export Templates > download for your Godot version.
2. Install JDK 17 and Android SDK (platform-tools, build-tools 34, platform 34, cmdline-tools).
   Editor Settings > Export > Android: set SDK path, JDK path, debug keystore.
3. Project > Install Android Build Template (not needed for default export).
4. Project > Export > Add > Android. Enable `arm64-v8a`. Landscape is already set.
5. Export Project > `.apk`. Install with `adb install game.apk`.
Renderer is GL Compatibility for wide mid-range phone support.

## Architecture (how to extend)
- `scripts/data/character_db.gd`: add a ninja = add one dict entry (+ ORDER). Stats, element, ability.
- `scripts/entities/fighter.gd`: all combat. Player / Enemy / Companion only implement `think()`.
- `scripts/entities/abilities.gd`: ability kinds ("projectile", "aoe"). Add kinds here.
- `scripts/world/island.gd`: world + chapter flow (`_run_story`). Next chapters = new coroutines + steps.
- `scripts/autoload/`: Loc (AR/EN), GameState (save/progress), Sfx (procedural audio).
- Saves: `user://save.json`, `user://settings.json`; auto-saves on each checkpoint, every 45 s, and on app pause/close.

## v2 additions
- Replay chapters: Main menu > Mission Select. Upgrades (skills, weapon, costumes, achievements): Pause > Upgrades or Main menu.
- USE button: talk to NPCs/allies, pull levers, read scrolls, ask a companion to use an element on a puzzle target,
  restore stolen powers with Skylor near a crystal. Climb: walk into the vine-covered walls (cliff, temple column).
- Add a boss: edit `Boss.build()` in `scripts/entities/boss.gd`. Add a chapter: append a `_bNN` beat in `chapters.gd`.

## Android APK
Project is export-ready (`export_presets.cfg`: arm64-v8a, landscape, immersive, non-gradle debug-signed).
No APK exists yet. Build from a phone: see `docs/BUILD_APK_FROM_PHONE.md` (GitHub Actions workflow in `.github/workflows/build-apk.yml`).

## Static checks (no Godot needed)
`python3 tests/static_check.py` and `python3 tests/deep_check.py` (see REPORT.md for what they do and do not prove).
