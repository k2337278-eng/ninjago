# Season 4 campaign - implementation status

IMPORTANT: ALL in-game story text is ORIGINAL DRAFT wording, not quotes from the show.
The chapter ORDER, who is stolen from and when, who is captured, which bosses appear, the
Skylor power description and the Anacondrai plan details are DESIGN PLACEHOLDERS that must be
verified against an episode guide before being treated as canon. Items marked VERIFY below are
the ones most likely to differ from the series.

Beat index == `GameState.story_step`. Chapter first-beats: 1:0, 2:1, 3:2, 4:4, 5:8, 6:10, 7:12, 8:14, 9:16, 10:18.

| Ch | Title | Beats | Implemented content (written, not run) | VERIFY |
|---|---|---|---|---|
| 1 | The Invitation | 0 | narration + arrival cutscene | invitation scene itself is narration only |
| 2 | Arrival at Chen's Island | 1 | walk to arena, contestants welcomed by Chen | real contestant roster |
| 3 | The Tournament Begins | 2-3 | match 1 (contender), match 2 (group) | named opponents |
| 4 | Elemental Rivals | 4-7 | elemental rival duel, survival, race (10 checkpoints), skill challenge, results table | rival identities |
| 5 | Hidden Secrets | 8-9 | 3 sigil puzzles (crate+plate, fire barricade, cliff climb) -> grotto gate -> Arena Warden boss (2 phases) | Warden is an invented boss |
| 6 | The Power Theft | 10-11 | scripted theft of 2 companions' powers, Skylor joins, ambush, restore via crystal | who is drained, when |
| 7 | The Anacondrai Plan | 12-13 | serpent ruins, player power drained by trap, 3 tablets, Anacondrai Warlord boss (2 phases), restore #2, 2 allies captured | Warlord invented; captive choice |
| 8 | Rescue Missions | 14-15 | cave cage (guards), temple cage (element lock + guards), restore player power | who is captured |
| 9 | The Final Tournament | 16-17 | round 1 (elites), round 2 Tournament Champion boss, results | champion invented |
| 10 | The Final Battle | 18-20 | prep, Master Chen boss (3 phases, summons, telegraphed attacks), ending | Chen's real final form/abilities |

Power theft is story-driven only: `GameState.sync_story_state(step)` derives which powers are
drained from the story step; gameplay defeat never removes a power. A drained ninja uses the
fallback "Focus Strike" and cannot use Spinjitzu; elemental puzzles needing that element are blocked
until restored.

Map and Inventory (pause menu) show discovered areas, collectibles and re-readable scrolls.
