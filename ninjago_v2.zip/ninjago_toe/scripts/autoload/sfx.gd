extends Node
## Procedurally generated placeholder SFX + music (original, license-free).

const RATE := 22050
var _sounds := {}
var _players: Array = []
var _music: AudioStreamPlayer

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_sounds["swing"] = _tone(420, 180, 0.16, 0.6, 0.5)
	_sounds["hit"] = _tone(170, 60, 0.18, 0.5, 0.7)
	_sounds["hurt"] = _tone(250, 90, 0.2, 0.3, 0.6)
	_sounds["block"] = _tone(800, 400, 0.12, 0.3, 0.6)
	_sounds["fire"] = _tone(300, 120, 0.5, 0.7, 0.6)
	_sounds["zap"] = _tone(1200, 200, 0.35, 0.5, 0.6)
	_sounds["quake"] = _tone(70, 40, 0.5, 0.4, 0.8)
	_sounds["ice"] = _tone(1500, 700, 0.4, 0.2, 0.5)
	_sounds["energy"] = _tone(500, 1100, 0.4, 0.1, 0.5)
	_sounds["spin"] = _tone(200, 600, 0.6, 0.3, 0.5)
	_sounds["jump"] = _tone(300, 600, 0.15, 0.0, 0.5)
	_sounds["ui"] = _tone(880, 880, 0.08, 0.0, 0.5)
	_sounds["coin"] = _tone(1000, 1500, 0.12, 0.0, 0.5)
	_sounds["win"] = _tone(500, 1000, 0.5, 0.0, 0.5)
	for i in 8:
		var p := AudioStreamPlayer.new()
		add_child(p)
		_players.append(p)
	_music = AudioStreamPlayer.new()
	add_child(_music)

func _tone(f0: float, f1: float, dur: float, noise: float, vol: float) -> AudioStreamWAV:
	var n := int(RATE * dur)
	var data := PackedByteArray()
	data.resize(n * 2)
	var phase := 0.0
	for i in n:
		var t := float(i) / n
		phase += TAU * lerpf(f0, f1, t) / RATE
		var s := sin(phase) * (1.0 - noise) + randf_range(-1.0, 1.0) * noise
		s *= pow(1.0 - t, 2.0) * vol
		data.encode_s16(i * 2, int(clampf(s, -1.0, 1.0) * 32767.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = RATE
	w.data = data
	return w

func play(sound_name: String, pitch := 1.0) -> void:
	if not _sounds.has(sound_name):
		return
	var vol: float = float(GameState.settings.get("sfx", 1.0))
	var chosen: AudioStreamPlayer = _players[0]
	for p in _players:
		if not p.playing:
			chosen = p
			break
	chosen.stream = _sounds[sound_name]
	chosen.pitch_scale = pitch * randf_range(0.95, 1.05)
	chosen.volume_db = linear_to_db(maxf(0.001, vol))
	chosen.play()

func start_music() -> void:
	if _music.stream == null:
		_music.stream = _make_music()
	apply_music_volume()
	if not _music.playing:
		_music.play()

func apply_music_volume() -> void:
	_music.volume_db = linear_to_db(maxf(0.001, float(GameState.settings.get("music", 0.7))) * 0.3)

func _make_music() -> AudioStreamWAV:
	var rate := 11025
	var beat := 0.38
	var melody := [0, 3, 7, 5, 3, 7, 10, 7, 12, 10, 7, 5, 3, 5, 7, 3]
	var n := int(rate * beat * melody.size())
	var data := PackedByteArray()
	data.resize(n * 2)
	var base := 220.0
	for i in n:
		var t := float(i) / rate
		var bi := int(t / beat) % melody.size()
		var lt := fmod(t, beat) / beat
		var f := base * pow(2.0, melody[bi] / 12.0)
		var s := sin(TAU * f * t) * 0.25 * pow(1.0 - lt, 1.5)
		var shift := 0 if (bi / 4) % 2 == 0 else -2
		var bf := base * 0.5 * pow(2.0, shift / 12.0)
		s += sin(TAU * bf * t) * (0.18 if bi % 2 == 0 else 0.07)
		data.encode_s16(i * 2, int(clampf(s, -1.0, 1.0) * 30000.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.data = data
	w.loop_mode = AudioStreamWAV.LOOP_FORWARD
	w.loop_begin = 0
	w.loop_end = n
	return w
