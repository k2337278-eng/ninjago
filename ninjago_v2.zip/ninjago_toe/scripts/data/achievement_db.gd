class_name AchievementDB
extends RefCounted
## Stat-based achievements unlock automatically (GameState.stat); the others are
## awarded explicitly by story code via GameState.award(id).

const ORDER := ["first_blood", "warrior", "slayer", "perfect_guard", "spinner", "elementalist",
	"coin_collector", "relic_hunter", "scholar", "explorer", "skilled", "level5", "level10",
	"rival_beaten", "survivor", "racer", "sharpshooter", "secret_finder", "warden_slayer",
	"restorer", "warlord_slayer", "rescuer", "champion", "chen_defeated", "perfectionist",
	"fashionista", "completionist"]

const DATA := {
	"first_blood": {"name": ["First Victory", "أول انتصار"], "desc": ["Defeat an enemy", "اهزم عدوًا"], "stat": "kills", "need": 1},
	"warrior": {"name": ["Warrior", "محارب"], "desc": ["Defeat 25 enemies", "اهزم 25 عدوًا"], "stat": "kills", "need": 25},
	"slayer": {"name": ["Tournament Veteran", "محارب مخضرم"], "desc": ["Defeat 100 enemies", "اهزم 100 عدو"], "stat": "kills", "need": 100},
	"perfect_guard": {"name": ["Perfect Guard", "الصدّ المثالي"], "desc": ["5 perfect blocks", "5 صدّات مثالية"], "stat": "perfect_blocks", "need": 5},
	"spinner": {"name": ["Spinner", "الدوّامة"], "desc": ["Use Spinjitzu 10 times", "استخدم السبينجيتزو 10 مرات"], "stat": "spins", "need": 10},
	"elementalist": {"name": ["Elementalist", "سيد العناصر"], "desc": ["Use elemental power 25 times", "استخدم القدرة العنصرية 25 مرة"], "stat": "abilities", "need": 25},
	"coin_collector": {"name": ["Coin Collector", "جامع العملات"], "desc": ["Collect all 20 coins", "اجمع كل العملات (20)"], "stat": "coins_collected", "need": 20},
	"relic_hunter": {"name": ["Relic Hunter", "صائد الآثار"], "desc": ["Find all 12 relics", "اعثر على كل الآثار (12)"], "stat": "relics", "need": 12},
	"scholar": {"name": ["Scholar", "العالِم"], "desc": ["Read all 6 scrolls", "اقرأ كل اللفائف (6)"], "stat": "scrolls", "need": 6},
	"explorer": {"name": ["Explorer", "المستكشف"], "desc": ["Discover all 10 areas", "اكتشف كل المناطق (10)"], "stat": "zones", "need": 10},
	"skilled": {"name": ["Skilled", "ماهر"], "desc": ["Spend 5 skill points", "أنفق 5 نقاط مهارة"], "stat": "skills_spent", "need": 5},
	"level5": {"name": ["Rising Ninja", "نينجا صاعد"], "desc": ["Reach level 5", "بلغ المستوى 5"], "stat": "level", "need": 5},
	"level10": {"name": ["Elite Ninja", "نينجا نخبة"], "desc": ["Reach level 10", "بلغ المستوى 10"], "stat": "level", "need": 10},
	"rival_beaten": {"name": ["Rival Beaten", "هزمت المنافس"], "desc": ["Win your rival duel", "اربح مبارزة المنافس"]},
	"survivor": {"name": ["Survivor", "الناجي"], "desc": ["Win the survival challenge", "اربح تحدي البقاء"]},
	"racer": {"name": ["Racer", "المتسابق"], "desc": ["Win the race", "اربح السباق"]},
	"sharpshooter": {"name": ["Sharpshooter", "القناص"], "desc": ["Win the skill challenge", "اربح تحدي المهارة"]},
	"secret_finder": {"name": ["Secret Finder", "كاشف الأسرار"], "desc": ["Enter the Hidden Grotto", "ادخل الكهف الخفي"]},
	"warden_slayer": {"name": ["Warden Slayer", "قاهر الحارس"], "desc": ["Defeat the Arena Warden", "اهزم حارس الساحة"]},
	"restorer": {"name": ["Power Restorer", "مستعيد القوى"], "desc": ["Restore a stolen power", "استعد قوة مسلوبة"]},
	"warlord_slayer": {"name": ["Serpent Slayer", "قاهر الثعابين"], "desc": ["Defeat the Anacondrai Warlord", "اهزم قائد الأناكوندراي"]},
	"rescuer": {"name": ["Rescuer", "المنقذ"], "desc": ["Rescue both captives", "أنقذ الأسيرين"]},
	"champion": {"name": ["Tournament Champion", "بطل البطولة"], "desc": ["Win the final tournament", "اربح البطولة الأخيرة"]},
	"chen_defeated": {"name": ["Final Victory", "النصر الأخير"], "desc": ["Defeat Master Chen", "اهزم الماستر تشِن"]},
	"perfectionist": {"name": ["Perfectionist", "المثالي"], "desc": ["Get an S rating", "احصل على تقييم S"]},
	"fashionista": {"name": ["New Look", "مظهر جديد"], "desc": ["Equip a costume", "ارتدِ زيًا جديدًا"]},
	"completionist": {"name": ["Completionist", "المكتمل"], "desc": ["Collect every coin, relic and scroll", "اجمع كل العملات والآثار واللفائف"]},
}
