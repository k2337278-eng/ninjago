class_name CharacterDB
extends RefCounted
## Data-driven character definitions. To add a ninja (e.g. Skylor), add an entry
## here and to ORDER. No other system needs to change.

const ORDER := ["kai", "jay", "cole", "zane", "lloyd"]
## Story-only characters (never selectable at New Game). Skylor joins in Chapter 6.
const EXTRA := ["skylor"]

## Fallback used while a ninja's elemental power is stolen (story state).
const FOCUS := {"name": ["Focus Strike", "ضربة التركيز"], "kind": "aoe", "sfx": "quake",
	"center": "self", "status": "", "damage": 10.0, "radius": 3.0, "knockback": 5.0,
	"cooldown": 6.0, "color": Color(0.7, 0.7, 0.75)}

const SPIN := {"damage": 9.0, "radius": 2.8, "duration": 1.6, "cooldown": 10.0, "tick": 0.25}

const DATA := {
	"kai": {
		"name": ["Kai", "كاي"], "element": "fire",
		"suit": Color(0.78, 0.08, 0.08),
		"hp": 120.0, "speed": 6.4, "light": 10.0, "heavy": 24.0, "poise": 0.0,
		"ability": {"name": ["Fireball", "كرة النار"], "kind": "projectile", "sfx": "fire",
			"status": "burn", "status_time": 3.0, "damage": 28.0, "range": 16.0, "speed": 18.0,
			"cooldown": 4.0, "radius": 1.0, "splash": 2.2, "pierce": false,
			"color": Color(1.0, 0.45, 0.08)},
	},
	"jay": {
		"name": ["Jay", "جاي"], "element": "lightning",
		"suit": Color(0.1, 0.3, 0.9),
		"hp": 110.0, "speed": 6.8, "light": 9.0, "heavy": 21.0, "poise": 0.0,
		"ability": {"name": ["Lightning Strike", "ضربة البرق"], "kind": "aoe", "sfx": "zap",
			"center": "self", "status": "stun", "status_time": 1.2, "damage": 24.0,
			"radius": 5.5, "knockback": 4.0, "cooldown": 5.0,
			"color": Color(0.5, 0.8, 1.0)},
	},
	"cole": {
		"name": ["Cole", "كول"], "element": "earth",
		"suit": Color(0.14, 0.14, 0.17),
		"hp": 150.0, "speed": 5.4, "light": 12.0, "heavy": 28.0, "poise": 8.0,
		"ability": {"name": ["Earthquake Slam", "ضربة الزلزال"], "kind": "aoe", "sfx": "quake",
			"center": "front", "status": "", "damage": 30.0,
			"radius": 4.2, "knockback": 12.0, "cooldown": 6.0,
			"color": Color(0.55, 0.4, 0.25)},
	},
	"zane": {
		"name": ["Zane", "زين"], "element": "ice",
		"suit": Color(0.92, 0.92, 0.96),
		"hp": 110.0, "speed": 6.6, "light": 9.0, "heavy": 20.0, "poise": 0.0,
		"ability": {"name": ["Ice Shards", "شظايا الجليد"], "kind": "projectile", "sfx": "ice",
			"status": "slow", "status_time": 3.5, "damage": 20.0, "range": 15.0, "speed": 16.0,
			"cooldown": 4.5, "radius": 1.0, "splash": 3.0, "pierce": false,
			"color": Color(0.6, 0.9, 1.0)},
	},
	"lloyd": {
		"name": ["Lloyd", "لويد"], "element": "energy",
		"suit": Color(0.1, 0.65, 0.2),
		"hp": 115.0, "speed": 6.6, "light": 10.0, "heavy": 22.0, "poise": 0.0,
		"ability": {"name": ["Energy Wave", "موجة الطاقة"], "kind": "projectile", "sfx": "energy",
			"status": "", "damage": 22.0, "range": 20.0, "speed": 22.0,
			"cooldown": 4.0, "radius": 1.4, "splash": 0.0, "pierce": true,
			"color": Color(0.4, 1.0, 0.5)},
	},
	"skylor": {
		"name": ["Skylor", "سكايلور"], "element": "absorb", "playable": false,
		"suit": Color(0.9, 0.55, 0.1),
		"hp": 115.0, "speed": 6.6, "light": 10.0, "heavy": 21.0, "poise": 0.0,
		"ability": {"name": ["Elemental Absorption", "امتصاص القوى"], "kind": "absorb", "sfx": "energy",
			"damage": 16.0, "radius": 5.0, "heal": 0.2, "status_time": 8.0, "cooldown": 8.0,
			"color": Color(1.0, 0.7, 0.1)},
	},
}

static func name_of(id: String) -> String:
	return Loc.pick(DATA[id]["name"])

static func ability_name(id: String) -> String:
	return Loc.pick(DATA[id]["ability"]["name"])
