class_name CostumeDB
extends RefCounted
## Costumes recolour the player's minifigure. Unlock rules are code, not saved.

const ORDER := ["default", "tournament", "golden", "shadow", "relic", "champion"]

const DATA := {
	"default": {"name": ["Classic Gi", "الزي الكلاسيكي"], "tint": Color.WHITE, "accent": Color.WHITE, "mix": 0.0,
		"how": ["Always available", "متاح دائمًا"]},
	"tournament": {"name": ["Tournament Gi", "زي البطولة"], "tint": Color(0.95, 0.95, 0.9), "accent": Color(0.9, 0.75, 0.2), "mix": 0.55,
		"how": ["Finish Chapter 3", "أنهِ الفصل الثالث"]},
	"golden": {"name": ["Golden Gi", "الزي الذهبي"], "tint": Color(1.0, 0.8, 0.15), "accent": Color(1, 1, 1), "mix": 0.7,
		"how": ["Collect all 20 coins", "اجمع كل العملات (20)"]},
	"shadow": {"name": ["Shadow Gi", "زي الظل"], "tint": Color(0.08, 0.08, 0.12), "accent": Color(0.55, 0.15, 0.8), "mix": 0.75,
		"how": ["Defeat the Arena Warden", "اهزم حارس الساحة"]},
	"relic": {"name": ["Relic Gi", "زي الآثار"], "tint": Color(0.3, 0.9, 1.0), "accent": Color(1, 1, 1), "mix": 0.6,
		"how": ["Collect all 12 relics", "اجمع كل الآثار (12)"]},
	"champion": {"name": ["Champion Gi", "زي البطل"], "tint": Color(0.55, 0.15, 0.55), "accent": Color(1.0, 0.85, 0.2), "mix": 0.65,
		"how": ["Defeat Master Chen", "اهزم الماستر تشِن"]},
}

static func unlocked(id: String) -> bool:
	match id:
		"default":
			return true
		"tournament":
			return GameState.max_step >= 4
		"golden":
			return int(GameState.stats.get("coins_collected", 0)) >= 20
		"shadow":
			return GameState.achievements.has("warden_slayer")
		"relic":
			return int(GameState.stats.get("relics", 0)) >= 12
		"champion":
			return GameState.achievements.has("chen_defeated")
	return false

static func apply(cfg: Dictionary, id: String) -> Dictionary:
	if id == "default" or not DATA.has(id) or not unlocked(id):
		return cfg
	var d: Dictionary = DATA[id]
	var out := cfg.duplicate()
	var base: Color = cfg.get("suit", Color(0.8, 0.1, 0.1))
	out["suit"] = base.lerp(d["tint"], float(d["mix"]))
	out["accent"] = d["accent"]
	return out
