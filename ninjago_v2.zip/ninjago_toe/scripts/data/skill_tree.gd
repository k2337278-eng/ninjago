class_name SkillTree
extends RefCounted
## Skill tree (player only) + stat application for player and companions.
## Skill points: +1 per level, +1-2 per chapter rating, +bonus for bosses/side missions.

const ORDER := ["vitality", "might", "agility", "focus", "iron_guard", "combo_master", "spin_master", "mastery"]

const DATA := {
	"vitality": {"name": ["Vitality", "الحيوية"], "desc": ["+8% max health per level", "+8% صحة قصوى لكل مستوى"], "max": 5, "req": ["", 0]},
	"might": {"name": ["Might", "القوة"], "desc": ["+6% damage per level", "+6% ضرر لكل مستوى"], "max": 5, "req": ["", 0]},
	"agility": {"name": ["Agility", "الرشاقة"], "desc": ["+4% move speed per level", "+4% سرعة حركة لكل مستوى"], "max": 5, "req": ["", 0]},
	"focus": {"name": ["Focus", "التركيز"], "desc": ["-6% ability cooldown per level", "-6% من زمن إعادة القدرة لكل مستوى"], "max": 5, "req": ["", 0]},
	"iron_guard": {"name": ["Iron Guard", "الحارس الحديدي"], "desc": ["Better blocking, wider perfect-block window", "صدّ أقوى ونافذة صدّ مثالي أوسع"], "max": 3, "req": ["vitality", 2]},
	"combo_master": {"name": ["Combo Master", "سيد الضربات"], "desc": ["+10% combo finisher damage per level", "+10% ضرر الضربة الأخيرة لكل مستوى"], "max": 3, "req": ["might", 2]},
	"spin_master": {"name": ["Spinjitzu Master", "سيد السبينجيتزو"], "desc": ["+12% Spinjitzu damage, +0.2s duration per level", "+12% ضرر السبينجيتزو و+0.2 ثانية لكل مستوى"], "max": 3, "req": ["agility", 2]},
	"mastery": {"name": ["Elemental Mastery", "إتقان العنصر"], "desc": ["+10% elemental ability damage per level", "+10% ضرر القدرة العنصرية لكل مستوى"], "max": 5, "req": ["focus", 2]},
}

static func lvl(id: String) -> int:
	return int(GameState.skills.get(id, 0))

static func can_buy(id: String) -> bool:
	var d: Dictionary = DATA[id]
	if lvl(id) >= int(d["max"]) or GameState.skill_points < 1:
		return false
	var r: Array = d["req"]
	if str(r[0]) != "" and lvl(str(r[0])) < int(r[1]):
		return false
	return true

static func buy(id: String) -> bool:
	if not can_buy(id):
		return false
	GameState.skills[id] = lvl(id) + 1
	GameState.skill_points -= 1
	GameState.stat("skills_spent")
	GameState.save_game()
	return true

static func respec() -> void:
	var total := 0
	for id in ORDER:
		total += lvl(id)
	GameState.skills = {}
	GameState.skill_points += total
	GameState.save_game()

## with_skills=true for the player (skills + weapon); false for companions (level scaling only).
static func apply(f: Fighter, with_skills := true) -> void:
	var ratio := f.health / maxf(f.max_health, 1.0)
	var s := 1 if with_skills else 0
	f.max_health = f.base_hp * GameState.health_multiplier() * (1.0 + 0.08 * lvl("vitality") * s)
	f.health = f.max_health * ratio
	f.move_speed = f.base_speed * (1.0 + 0.04 * lvl("agility") * s)
	f.dmg_mult = GameState.damage_multiplier() * (GameState.weapon_multiplier() if with_skills else 1.0)
	f.skill_dmg = 1.0 + 0.06 * lvl("might") * s
	f.cd_scale = 1.0 - 0.06 * lvl("focus") * s
	f.ability_mult = 1.0 + 0.10 * lvl("mastery") * s
	f.spin_mult = 1.0 + 0.12 * lvl("spin_master") * s
	f.spin_bonus = 0.2 * lvl("spin_master") * s
	f.finisher_mult = 1.7 + 0.1 * lvl("combo_master") * s
	f.perfect_window = 0.25 + 0.03 * lvl("iron_guard") * s
	f.block_reduce = 0.25 - 0.05 * lvl("iron_guard") * s
