class_name Abilities
extends RefCounted
## Elemental ability dispatcher. Kinds: "projectile", "aoe". Add new kinds here.

static func cast(f: Fighter, ab: Dictionary) -> void:
	match ab["kind"]:
		"projectile":
			Projectile.fire(f, ab)
		"aoe":
			_aoe(f, ab)
		"absorb":
			_absorb(f, ab)

const ELEMENT_BY_SFX := {"fire": "fire", "zap": "lightning", "quake": "earth", "ice": "ice", "energy": "energy"}

static func element_of(ab: Dictionary) -> String:
	return str(ELEMENT_BY_SFX.get(str(ab.get("sfx", "")), "none"))

## Lets elemental puzzle targets react to an ability area (aoe/absorb).
static func touch_elements(host: Node, center: Vector3, radius: float, element: String, src) -> void:
	for n in host.get_tree().get_nodes_in_group("element_target"):
		var t := n as ElementTarget
		if t == null or t.done:
			continue
		if Vector2(t.global_position.x - center.x, t.global_position.z - center.z).length() <= radius + t.hit_radius:
			t.on_element(element, src)

## Projectiles: returns true when a puzzle target was struck (projectile stops).
static func projectile_touch(node: Node3D, ab: Dictionary, src) -> bool:
	var el := element_of(ab)
	for n in node.get_tree().get_nodes_in_group("element_target"):
		var t := n as ElementTarget
		if t == null or t.done:
			continue
		if node.global_position.distance_to(t.global_position) < t.hit_radius:
			t.on_element(el, src)
			return true
	return false

static func _absorb(f: Fighter, ab: Dictionary) -> void:
	var radius: float = ab["radius"]
	var col: Color = ab["color"]
	Effects.ring(f, f.global_position, radius, col)
	Effects.burst(f, f.global_position + Vector3(0, 1.0, 0), col, 30, 7.0)
	Sfx.play("energy", 0.8)
	var dur: float = ab.get("status_time", 8.0)
	for n in f.get_tree().get_nodes_in_group("fighters"):
		var t := n as Fighter
		if t == null or t.state == Fighter.S.DEAD:
			continue
		var d := Vector2(t.global_position.x - f.global_position.x, t.global_position.z - f.global_position.z).length()
		if d > radius * 1.6:
			continue
		if t.team == f.team:
			if not t.downed:
				t.health = minf(t.max_health, t.health + t.max_health * float(ab.get("heal", 0.2)))
				t.health_changed.emit(t)
				t.statuses["empower"] = dur
		elif d <= radius:
			t.take_damage(float(ab["damage"]) * f.dmg_scale() * f.ability_mult, f, 5.0, 0.0, true)

static func apply_status(t: Fighter, ab: Dictionary) -> void:
	var s: String = ab.get("status", "")
	if s == "":
		return
	var dur: float = ab.get("status_time", 3.0)
	if s == "stun":
		t.apply_stagger(dur)
	else:
		t.statuses[s] = dur

static func _aoe(f: Fighter, ab: Dictionary) -> void:
	var center := f.global_position
	if ab.get("center", "self") == "front":
		center += f.face_dir * 3.0
	var radius: float = ab["radius"]
	Effects.ring(f, center, radius, ab["color"])
	Effects.burst(f, center + Vector3(0, 0.5, 0), ab["color"], 30, 8.0)
	Effects.shake(f, 0.3)
	touch_elements(f, center, radius, element_of(ab), f)
	for n in f.get_tree().get_nodes_in_group("fighters"):
		var t := n as Fighter
		if t == null or t.team == f.team or t.state == Fighter.S.DEAD:
			continue
		var d := Vector2(t.global_position.x - center.x, t.global_position.z - center.z).length()
		if d <= radius:
			if t.take_damage(float(ab["damage"]) * f.dmg_scale() * f.ability_mult, f, float(ab.get("knockback", 6.0)), 0.0, true):
				apply_status(t, ab)
