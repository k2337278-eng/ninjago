class_name CameraRig
extends Node3D
## Third-person orbit camera driven by touch-drag (or mouse-drag on desktop).

var target: Node3D
var yaw := 0.0
var pitch := -0.35
var dist := 7.5
var cam: Camera3D
var shake := 0.0

func _ready() -> void:
	add_to_group("camera_rig")
	cam = Camera3D.new()
	cam.fov = 65.0
	cam.far = 220.0
	add_child(cam)
	cam.position = Vector3(0, 0, dist)
	cam.current = true

func rotate_view(d: Vector2) -> void:
	yaw -= d.x * 0.005
	pitch = clampf(pitch + d.y * 0.004, -1.2, -0.05)

func _process(delta: float) -> void:
	if target != null and is_instance_valid(target):
		global_position = global_position.lerp(target.global_position + Vector3(0, 1.3, 0), 1.0 - exp(-12.0 * delta))
	rotation = Vector3(pitch, yaw, 0.0)
	shake = move_toward(shake, 0.0, delta * 1.5)
	cam.h_offset = randf_range(-1.0, 1.0) * shake * 0.3
	cam.v_offset = randf_range(-1.0, 1.0) * shake * 0.3
