class_name Effects
extends RefCounted
## Pooled particle bursts, expanding rings and camera shake.

static var _pool: Array = []

static func burst(host: Node, pos: Vector3, color: Color, amount := 14, speed := 5.0) -> void:
	if host == null or not host.is_inside_tree():
		return
	var p: CPUParticles3D = null
	var alive: Array = []
	for q in _pool:
		if is_instance_valid(q):
			alive.append(q)
			if p == null and not q.emitting:
				p = q
	_pool = alive
	if p == null and _pool.size() < 16:
		p = CPUParticles3D.new()
		var sm := SphereMesh.new()
		sm.radius = 0.06
		sm.height = 0.12
		sm.radial_segments = 6
		sm.rings = 3
		var mat := StandardMaterial3D.new()
		mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		sm.material = mat
		p.mesh = sm
		p.one_shot = true
		p.explosiveness = 1.0
		p.lifetime = 0.5
		p.direction = Vector3.UP
		p.spread = 180.0
		p.gravity = Vector3(0, -8, 0)
		p.emitting = false
		host.get_tree().current_scene.add_child(p)
		_pool.append(p)
	if p == null:
		return
	(p.mesh.material as StandardMaterial3D).albedo_color = color
	p.amount = amount
	p.initial_velocity_min = speed * 0.5
	p.initial_velocity_max = speed
	p.global_position = pos
	p.restart()
	p.emitting = true

static func ring(host: Node, pos: Vector3, radius: float, color: Color) -> void:
	if host == null or not host.is_inside_tree():
		return
	var mi := MeshInstance3D.new()
	var m := CylinderMesh.new()
	m.top_radius = 1.0
	m.bottom_radius = 1.0
	m.height = 0.12
	m.radial_segments = 24
	m.rings = 1
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.albedo_color = Color(color, 0.55)
	m.material = mat
	mi.mesh = m
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	host.get_tree().current_scene.add_child(mi)
	mi.global_position = Vector3(pos.x, pos.y + 0.1, pos.z)
	mi.scale = Vector3(0.2, 1.0, 0.2)
	var tw := mi.create_tween()
	tw.set_parallel(true)
	tw.tween_property(mi, "scale", Vector3(radius, 1.0, radius), 0.3)
	tw.tween_property(mat, "albedo_color:a", 0.0, 0.4)
	tw.chain().tween_callback(mi.queue_free)

static func shake(host: Node, amount: float) -> void:
	if host == null or not host.is_inside_tree():
		return
	var r = host.get_tree().get_first_node_in_group("camera_rig")
	if r != null:
		r.shake = maxf(r.shake, amount)

## Static red danger disc that lingers for `dur` seconds (boss telegraphs).
static func warn_ring(host: Node, pos: Vector3, radius: float, dur: float) -> void:
	if host == null or not host.is_inside_tree():
		return
	var mi := MeshInstance3D.new()
	var m := CylinderMesh.new()
	m.top_radius = radius
	m.bottom_radius = radius
	m.height = 0.06
	m.radial_segments = 24
	m.rings = 1
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.albedo_color = Color(1.0, 0.1, 0.1, 0.0)
	m.material = mat
	mi.mesh = m
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	host.get_tree().current_scene.add_child(mi)
	mi.global_position = Vector3(pos.x, pos.y + 0.08, pos.z)
	var tw := mi.create_tween()
	tw.tween_property(mat, "albedo_color:a", 0.45, dur * 0.8)
	tw.tween_property(mat, "albedo_color:a", 0.0, dur * 0.2)
	tw.tween_callback(mi.queue_free)
