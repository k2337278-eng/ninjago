class_name Player
extends Fighter
## The single character the player controls (chosen at New Game).

signal interact_pressed
signal feedback(text: String)
signal pause_requested

var controls: TouchControls
var cam_rig: CameraRig
var input_locked := false

func _ready() -> void:
	team = "player"
	dmg_mult = GameState.damage_multiplier() * GameState.weapon_multiplier()
	super()

func bind_controls(c: TouchControls) -> void:
	controls = c
	c.action_pressed.connect(_on_action)
	c.action_released.connect(_on_release)
	if cam_rig != null:
		c.look.connect(cam_rig.rotate_view)

func _on_action(a: String) -> void:
	if a == "pause":
		pause_requested.emit()
		return
	if input_locked or state == S.DEAD:
		return
	match a:
		"light":
			try_light()
		"heavy":
			try_heavy()
		"jump":
			try_jump()
		"spin":
			if power_stolen:
				feedback.emit(Loc.pick(["Spinjitzu is drained!", "قوة السبينجيتزو مسلوبة!"]))
			else:
				try_spin()
		"power":
			try_ability()
		"dodge":
			try_dodge()
		"block":
			set_blocking(true)
		"interact":
			interact_pressed.emit()

func _on_release(a: String) -> void:
	if a == "block":
		set_blocking(false)

func _unhandled_key_input(event: InputEvent) -> void:
	var k := event as InputEventKey
	if k == null or k.echo:
		return
	var a := ""
	match k.keycode:
		KEY_J:
			a = "light"
		KEY_K:
			a = "heavy"
		KEY_SPACE:
			a = "jump"
		KEY_Q:
			a = "spin"
		KEY_E:
			a = "power"
		KEY_SHIFT:
			a = "dodge"
		KEY_L:
			a = "block"
		KEY_F:
			a = "interact"
		KEY_ESCAPE:
			a = "pause"
	if a == "":
		return
	if k.pressed:
		_on_action(a)
	else:
		_on_release(a)

func think(_delta: float) -> void:
	aim_dir = Vector3.ZERO
	var v := Vector2.ZERO
	if not input_locked:
		if controls != null:
			v = controls.move_vector
		v += Vector2(
			float(Input.is_key_pressed(KEY_D)) - float(Input.is_key_pressed(KEY_A)),
			float(Input.is_key_pressed(KEY_S)) - float(Input.is_key_pressed(KEY_W)))
		v = v.limit_length(1.0)
	var yaw := cam_rig.yaw if cam_rig != null else 0.0
	move_input = Vector3(v.x, 0.0, v.y).rotated(Vector3.UP, yaw)
