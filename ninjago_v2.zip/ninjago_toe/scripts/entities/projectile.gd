class_name Projectile
extends Node3D
## Pooled elemental projectile (fire / ice / energy). Reused instead of freed.

static var _pool: Array = []

var ab: Dictionary = {}
var src: Fighter
var src_team := ""
var dir := Vector3(0, 0, -1)
var spd := 15.0
var dmg := 10.0
var traveled := 0.0
var active := false
var hit_ids := {}
var _mat: StandardMaterial3D
var _parts: CPUParticles3D
var _light: OmniLight3D

static func fire(f: Fighter, a: Dictionary) -> void:
	var p: Projectile = null
	while _pool.size() > 0 and p == null:
		var c = _pool.pop_back()
		if is_instance_valid(c):
			p = c
	if p == null:
		p = Projectile.new()
		p._build()
	if p.get_parent() == null:
		f.get_tree().current_scene.add_child(p)
	p.launch(f, a)

func _build() -> void:
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.35
	sm.height = 0.7
	sm.radial_segments = 10
	sm.rings = 5
	_mat = StandardMaterial3D.new()
	_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	sm.material = _mat
	mi.mesh = sm
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)
	_parts = CPUParticles3D.new()
	var pm := SphereMesh.new()
	pm.radius = 0.08
	pm.height = 0.16
	pm.radial_segments = 6
	pm.rings = 3
	var pmat := StandardMaterial3D.new()
	pmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	pmat.vertex_color_use_as_albedo = true
	pm.material = pmat
	_parts.mesh = pm
	_parts.amount = 14
	_parts.lifetime = 0.4
	_parts.local_coords = false
	_parts.direction = Vector3.UP
	_parts.spread = 60.0
	_parts.initial_velocity_min = 0.5
	_parts.initial_velocity_max = 1.5
	_parts.gravity = Vector3(0, 1.5, 0)
	add_child(_parts)
	_light = OmniLight3D.new()
	_light.light_energy = 1.3
	_light.omni_range = 5.0
	_light.shadow_enabled = false
	add_child(_light)

func launch(f: Fighter, a: Dictionary) -> void:
	ab = a
	src = f
	src_team = f.team
	dir = f.face_dir.normalized()
	spd = float(a["speed"])
	dmg = float(a["damage"]) * f.dmg_scale() * f.ability_mult
	traveled = 0.0
	hit_ids.clear()
	var c: Color = a["color"]
	_mat.albedo_color = c
	_parts.color = c
	_light.light_color = c
	global_position = f.global_position + Vector3(0, 1.0, 0) + dir * 0.9
	visible = true
	active = true
	_parts.restart()
	_parts.emitting = true
	set_physics_process(true)

func _physics_process(delta: float) -> void:
	if not active:
		return
	var step := spd * delta
	global_position += dir * step
	traveled += step
	if Abilities.projectile_touch(self, ab, src if is_instance_valid(src) else null):
		_finish()
		return
	for n in get_tree().get_nodes_in_group("fighters"):
		var t := n as Fighter
		if t == null or t.team == src_team or t.state == Fighter.S.DEAD or hit_ids.has(t.get_instance_id()):
			continue
		var d := Vector2(t.global_position.x - global_position.x, t.global_position.z - global_position.z).length()
		if d <= float(ab["radius"]) and absf(t.global_position.y + 0.8 - global_position.y) < 1.6:
			hit_ids[t.get_instance_id()] = true
			_hit(t)
			if not bool(ab.get("pierce", false)):
				_finish()
				return
	if traveled >= float(ab["range"]):
		_finish()

func _hit(t: Fighter) -> void:
	var s: Node3D = src if is_instance_valid(src) else null
	if t.take_damage(dmg, s, 7.0, 0.0, true):
		Abilities.apply_status(t, ab)
	var c: Color = ab["color"]
	Effects.burst(self, t.global_position + Vector3(0, 1.0, 0), c, 20, 6.0)
	var splash := float(ab.get("splash", 0.0))
	if splash > 0.0:
		for n in get_tree().get_nodes_in_group("fighters"):
			var o := n as Fighter
			if o == null or o == t or o.team == src_team or o.state == Fighter.S.DEAD:
				continue
			if o.global_position.distance_to(t.global_position) <= splash:
				if o.take_damage(dmg * 0.6, s, 5.0, 0.0, true):
					Abilities.apply_status(o, ab)
		Effects.ring(self, t.global_position, splash, c)

func _finish() -> void:
	active = false
	visible = false
	_parts.emitting = false
	set_physics_process(false)
	_pool.append(self)
