class_name CharPreview
extends SubViewportContainer
## Rotating 3D preview of a minifigure inside its own World3D.

var vp: SubViewport
var fig: Minifig
var pivot: Node3D

func _ready() -> void:
	stretch = true
	vp = SubViewport.new()
	vp.transparent_bg = true
	vp.own_world_3d = true
	vp.size = Vector2i(420, 520)
	add_child(vp)
	var env := Environment.new()
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.75, 0.75, 0.85)
	env.ambient_light_energy = 0.9
	var we := WorldEnvironment.new()
	we.environment = env
	vp.add_child(we)
	var light := DirectionalLight3D.new()
	light.rotation_degrees = Vector3(-35, -30, 0)
	vp.add_child(light)
	var cam := Camera3D.new()
	vp.add_child(cam)
	cam.look_at_from_position(Vector3(0, 1.0, 3.4), Vector3(0, 0.85, 0))
	pivot = Node3D.new()
	vp.add_child(pivot)

func show_character(id: String) -> void:
	if fig != null:
		fig.queue_free()
	fig = Minifig.new()
	pivot.add_child(fig)
	fig.build({"suit": CharacterDB.DATA[id]["suit"], "style": "ninja", "weapon": Minifig.WEAPONS.get(id, "")})

func _process(d: float) -> void:
	pivot.rotation.y += d * 0.8
	if fig != null:
		fig.update_anim(d, 0.0, false)
