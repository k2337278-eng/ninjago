extends Control
## Choose ONE ninja to play for the whole story. The others become AI companions.

var chosen := "kai"
var prev: CharPreview
var info: Label
var buttons := {}

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var bg := ColorRect.new()
	bg.color = Color(0.07, 0.07, 0.14)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var title := Label.new()
	title.text = Loc.t("choose")
	title.add_theme_font_size_override("font_size", 44)
	title.position = Vector2(40, 20)
	add_child(title)
	prev = CharPreview.new()
	prev.anchor_left = 0.03
	prev.anchor_right = 0.4
	prev.anchor_top = 0.14
	prev.anchor_bottom = 0.98
	add_child(prev)
	var right := VBoxContainer.new()
	right.anchor_left = 0.43
	right.anchor_right = 0.97
	right.anchor_top = 0.14
	right.anchor_bottom = 0.97
	right.add_theme_constant_override("separation", 10)
	add_child(right)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	right.add_child(row)
	for id in CharacterDB.ORDER:
		var b := Button.new()
		b.text = CharacterDB.name_of(id)
		b.custom_minimum_size = Vector2(120, 70)
		b.add_theme_font_size_override("font_size", 26)
		b.toggle_mode = true
		b.pressed.connect(_pick.bind(id))
		row.add_child(b)
		buttons[id] = b
	info = Label.new()
	info.add_theme_font_size_override("font_size", 28)
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info.size_flags_vertical = Control.SIZE_EXPAND_FILL
	right.add_child(info)
	var start := Button.new()
	start.text = Loc.t("start")
	start.custom_minimum_size = Vector2(300, 76)
	start.add_theme_font_size_override("font_size", 32)
	start.pressed.connect(_start)
	right.add_child(start)
	var back := Button.new()
	back.text = Loc.t("back")
	back.custom_minimum_size = Vector2(300, 60)
	back.add_theme_font_size_override("font_size", 26)
	back.pressed.connect(func(): get_tree().change_scene_to_file("res://scenes/main_menu.tscn"))
	right.add_child(back)
	_pick("kai")

func _pick(id: String) -> void:
	Sfx.play("ui")
	chosen = id
	for k in buttons.keys():
		buttons[k].button_pressed = (k == id)
	prev.show_character(id)
	var d: Dictionary = CharacterDB.DATA[id]
	info.text = "%s - %s\n%s %d | %s %.1f | %s %d/%d\n%s: %s" % [
		CharacterDB.name_of(id), Loc.t("el_" + str(d["element"])),
		Loc.t("stat_hp"), int(d["hp"]), Loc.t("stat_speed"), float(d["speed"]),
		Loc.t("stat_atk"), int(d["light"]), int(d["heavy"]),
		Loc.t("stat_power"), CharacterDB.ability_name(id)]

func _start() -> void:
	Sfx.play("ui")
	GameState.new_game(chosen)
	get_tree().change_scene_to_file("res://scenes/island.tscn")
