extends Control
## Main menu: Continue / New Game / Settings / Quit. Built in code.

var box: VBoxContainer
var settings_box: VBoxContainer
var q_btn: Button
var m_btn: Button

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	Sfx.start_music()
	var bg := ColorRect.new()
	bg.color = Color(0.07, 0.07, 0.14)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var prev := CharPreview.new()
	prev.anchor_left = 0.58
	prev.anchor_right = 0.98
	prev.anchor_top = 0.1
	prev.anchor_bottom = 0.98
	add_child(prev)
	var id: String = GameState.selected_char if GameState.has_save() else "kai"
	prev.show_character(id)
	var holder := VBoxContainer.new()
	holder.anchor_left = 0.05
	holder.anchor_right = 0.55
	holder.anchor_top = 0.08
	holder.anchor_bottom = 0.95
	holder.add_theme_constant_override("separation", 14)
	add_child(holder)
	var title := Label.new()
	title.text = Loc.t("title")
	title.add_theme_font_size_override("font_size", 46)
	title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	holder.add_child(title)
	var sub := Label.new()
	sub.text = Loc.t("subtitle")
	sub.add_theme_font_size_override("font_size", 26)
	holder.add_child(sub)
	box = VBoxContainer.new()
	box.add_theme_constant_override("separation", 12)
	holder.add_child(box)
	settings_box = VBoxContainer.new()
	settings_box.add_theme_constant_override("separation", 12)
	settings_box.visible = false
	holder.add_child(settings_box)
	_build_main()
	_build_settings()

func _btn(parent: Control, text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(380, 66)
	b.add_theme_font_size_override("font_size", 28)
	b.pressed.connect(func():
		Sfx.play("ui")
		cb.call())
	parent.add_child(b)
	return b

func _build_main() -> void:
	var cont := _btn(box, Loc.t("continue"), func():
		get_tree().change_scene_to_file("res://scenes/island.tscn"))
	cont.disabled = not GameState.has_save()
	_btn(box, Loc.t("new_game"), func():
		get_tree().change_scene_to_file("res://scenes/character_select.tscn"))
	var ms := _btn(box, Loc.t("missions"), func():
		get_tree().change_scene_to_file("res://scenes/mission_select.tscn"))
	ms.disabled = not GameState.has_save()
	var upg := _btn(box, Loc.t("upgrades"), func():
		var up := UpgradeScreen.new()
		add_child(up)
		up.open(null)
		await up.closed
		up.queue_free())
	upg.disabled = not GameState.has_save()
	_btn(box, Loc.t("settings"), func():
		box.visible = false
		settings_box.visible = true)
	if OS.get_name() != "Android" and OS.get_name() != "iOS":
		_btn(box, Loc.t("quit"), func(): get_tree().quit())

func _build_settings() -> void:
	_btn(settings_box, Loc.t("language"), func():
		GameState.settings["lang"] = "en" if Loc.lang == "ar" else "ar"
		Loc.set_lang(GameState.settings["lang"])
		GameState.save_settings()
		get_tree().reload_current_scene())
	q_btn = _btn(settings_box, Loc.t("quality") % Loc.t("q%d" % int(GameState.settings["quality"])), func():
		GameState.settings["quality"] = (int(GameState.settings["quality"]) + 1) % 3
		GameState.save_settings()
		q_btn.text = Loc.t("quality") % Loc.t("q%d" % int(GameState.settings["quality"])))
	m_btn = _btn(settings_box, Loc.t("music") % int(float(GameState.settings["music"]) * 100.0), func():
		var v := roundf((float(GameState.settings["music"]) + 0.25) * 4.0) / 4.0
		if v > 1.0:
			v = 0.0
		GameState.settings["music"] = v
		GameState.save_settings()
		Sfx.apply_music_volume()
		m_btn.text = Loc.t("music") % int(v * 100.0))
	_btn(settings_box, Loc.t("back"), func():
		settings_box.visible = false
		box.visible = true)
