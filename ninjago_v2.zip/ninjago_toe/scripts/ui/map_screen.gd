class_name MapScreen
extends Control
## Top-down island map: terrain, landmarks, discovered zone names, player/companions/objective.

signal closed

const WX := Vector2(-76.0, 76.0)
const WZ := Vector2(-73.0, 67.0)

var isl: Node3D
var rect := Rect2()
var labels := {}

func open(island: Node3D) -> void:
	isl = island
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	for z in island.ZONES:
		var l := Label.new()
		l.add_theme_font_size_override("font_size", 20)
		l.add_theme_constant_override("outline_size", 5)
		l.add_theme_color_override("font_outline_color", Color.BLACK)
		var seen: bool = bool(GameState.flags.get("zone_" + str(z["id"]), false))
		l.text = Loc.pick(z["name"]) if seen else "?"
		add_child(l)
		labels[str(z["id"])] = l
	var title := Label.new()
	title.text = Loc.t("map")
	title.add_theme_font_size_override("font_size", 36)
	title.position = Vector2(30, 14)
	add_child(title)
	var close := Button.new()
	close.text = Loc.t("close")
	close.custom_minimum_size = Vector2(200, 60)
	close.anchor_left = 1.0
	close.anchor_right = 1.0
	close.offset_left = -230
	close.offset_right = -30
	close.offset_top = 14
	close.add_theme_font_size_override("font_size", 26)
	close.pressed.connect(func(): closed.emit())
	add_child(close)

func _w2m(x: float, z: float) -> Vector2:
	return rect.position + Vector2((x - WX.x) / (WX.y - WX.x) * rect.size.x, (z - WZ.x) / (WZ.y - WZ.x) * rect.size.y)

func _r2m(x0: float, z0: float, x1: float, z1: float) -> Rect2:
	var a := _w2m(x0, z0)
	var b := _w2m(x1, z1)
	return Rect2(a, b - a)

func _process(_d: float) -> void:
	var s := size
	var ratio := (WX.y - WX.x) / (WZ.y - WZ.x)
	var h := s.y - 90.0
	var w := h * ratio
	if w > s.x - 40.0:
		w = s.x - 40.0
		h = w / ratio
	rect = Rect2(Vector2((s.x - w) * 0.5, 80.0), Vector2(w, h))
	if isl != null:
		for z in isl.ZONES:
			var zp: Vector3 = z["pos"]
			var l: Label = labels[str(z["id"])]
			var p := _w2m(zp.x, zp.z)
			l.position = p - Vector2(l.size.x * 0.5, 10.0)
	queue_redraw()

func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.04, 0.08, 0.16, 0.97))
	draw_rect(rect, Color(0.1, 0.4, 0.7))
	draw_rect(_r2m(-75, -72, 75, 66), Color(0.28, 0.55, 0.22))
	draw_rect(_r2m(-75, 36, 75, 64), Color(0.86, 0.78, 0.55))
	draw_rect(_r2m(-2.5, 9, 2.5, 41), Color(0.5, 0.47, 0.42))
	var k := rect.size.x / (WX.y - WX.x)
	draw_circle(_w2m(0, -6), 17.5 * k, Color(0.62, 0.6, 0.58))
	draw_arc(_w2m(0, -6), 9.0 * k, 0, TAU, 24, Color(0.4, 0.15, 0.15), 2.0)
	draw_rect(_r2m(-22, -59, 22, -45), Color(0.55, 0.5, 0.65))
	draw_rect(_r2m(40, -15, 56, 3), Color(0.7, 0.68, 0.62))
	draw_rect(_r2m(-57, -19.5, -43, -4.5), Color(0.3, 0.28, 0.28))
	draw_rect(_r2m(-62, -66, -34, -41), Color(0.3, 0.2, 0.4))
	draw_rect(_r2m(51, -47, 65, -33), Color(0.4, 0.37, 0.35))
	draw_arc(_w2m(38, -58), 10.0 * k, 0, TAU, 24, Color(0.4, 0.9, 1.0), 3.0)
	draw_rect(_r2m(-34.5, 8, -25.5, 14), Color(0.45, 0.43, 0.42))
	for i in 5:
		draw_rect(_r2m(16.3 + 5.5 * i, 23, 19.7 + 5.5 * i, 27), Color(0.55, 0.55, 0.6))
	draw_rect(rect, Color(1, 1, 1, 0.4), false, 2.0)
	if isl == null or isl.player == null:
		return
	if isl.marker != null and isl.marker.visible:
		draw_circle(_w2m(isl.marker.position.x, isl.marker.position.z), 9.0, Color(1.0, 0.9, 0.2))
	for c in isl.companions:
		if is_instance_valid(c):
			draw_circle(_w2m(c.global_position.x, c.global_position.z), 5.0, Color(0.3, 0.7, 1.0))
	var pp := _w2m(isl.player.global_position.x, isl.player.global_position.z)
	var f: Vector3 = isl.player.face_dir
	var fwd := Vector2(f.x, f.z).normalized() * 12.0
	var side := Vector2(-fwd.y, fwd.x) * 0.5
	draw_colored_polygon(PackedVector2Array([pp + fwd, pp - fwd * 0.6 + side, pp - fwd * 0.6 - side]), Color(1, 0.2, 0.2))
