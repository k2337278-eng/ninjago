class_name TouchControls
extends Control
## Virtual joystick (left), camera-drag (right), action buttons, pause.
## Uses raw screen-touch events so several fingers work at once. On desktop,
## project setting emulate_touch_from_mouse lets the mouse drive it.

signal action_pressed(action: String)
signal action_released(action: String)
signal look(delta: Vector2)

const JOY_R := 90.0

var enabled := true
var player: Fighter
var move_vector := Vector2.ZERO
var _joy_id := -1
var _joy_origin := Vector2.ZERO
var _joy_pos := Vector2.ZERO
var _look_id := -1
var _btn_touch := {}
var _buttons: Array = []
var _pause_pos := Vector2(60, 60)
var _last_size := Vector2.ZERO
var _joy_default := Vector2(180, 550)

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _layout() -> void:
	var s := get_viewport_rect().size
	_last_size = s
	var ins := _insets()
	var sx := s.x - ins.y
	_pause_pos = Vector2(60.0 + ins.x, 60.0)
	_joy_default = Vector2(180.0 + ins.x, s.y - 170.0)
	_buttons = [
		{"id": "light", "label": "ATK", "pos": Vector2(sx - 130, s.y - 130), "r": 72.0, "cd": ""},
		{"id": "heavy", "label": "HVY", "pos": Vector2(sx - 265, s.y - 85), "r": 54.0, "cd": ""},
		{"id": "jump", "label": "JMP", "pos": Vector2(sx - 85, s.y - 265), "r": 54.0, "cd": ""},
		{"id": "dodge", "label": "DGE", "pos": Vector2(sx - 235, s.y - 215), "r": 50.0, "cd": "dodge"},
		{"id": "power", "label": "PWR", "pos": Vector2(sx - 355, s.y - 150), "r": 52.0, "cd": "ability"},
		{"id": "spin", "label": "SPN", "pos": Vector2(sx - 345, s.y - 275), "r": 48.0, "cd": "spin"},
		{"id": "block", "label": "BLK", "pos": Vector2(sx - 415, s.y - 55), "r": 44.0, "cd": ""},
		{"id": "interact", "label": "USE", "pos": Vector2(sx - 120, s.y - 390), "r": 46.0, "cd": ""},
	]

func reset() -> void:
	for id in _btn_touch.keys():
		action_released.emit(_btn_touch[id])
	_btn_touch.clear()
	_joy_id = -1
	_look_id = -1
	move_vector = Vector2.ZERO

func set_enabled(on: bool) -> void:
	enabled = on
	if not on:
		reset()

func _input(event: InputEvent) -> void:
	if not enabled or not is_visible_in_tree():
		return
	if event is InputEventScreenTouch:
		var e := event as InputEventScreenTouch
		if e.pressed:
			_press(e.index, e.position)
		else:
			_release(e.index)
	elif event is InputEventScreenDrag:
		var d := event as InputEventScreenDrag
		_drag(d.index, d.position, d.relative)

func _press(idx: int, pos: Vector2) -> void:
	if pos.distance_to(_pause_pos) < 46.0:
		action_pressed.emit("pause")
		return
	for b in _buttons:
		if pos.distance_to(b["pos"]) <= float(b["r"]) * 1.15:
			_btn_touch[idx] = b["id"]
			action_pressed.emit(b["id"])
			return
	if pos.x < _last_size.x * 0.42 and _joy_id == -1:
		_joy_id = idx
		_joy_origin = pos
		_joy_pos = pos
	elif _look_id == -1:
		_look_id = idx

func _release(idx: int) -> void:
	if _btn_touch.has(idx):
		action_released.emit(_btn_touch[idx])
		_btn_touch.erase(idx)
	if idx == _joy_id:
		_joy_id = -1
		move_vector = Vector2.ZERO
	if idx == _look_id:
		_look_id = -1

func _drag(idx: int, pos: Vector2, rel: Vector2) -> void:
	if idx == _joy_id:
		_joy_pos = pos
		var v := (pos - _joy_origin).limit_length(JOY_R)
		move_vector = Vector2.ZERO if v.length() < 12.0 else v / JOY_R
	elif idx == _look_id:
		look.emit(rel)

func _process(_d: float) -> void:
	if get_viewport_rect().size != _last_size:
		_layout()
	queue_redraw()

func _draw() -> void:
	if not is_visible_in_tree():
		return
	var font := ThemeDB.fallback_font
	var s := _last_size
	var base := _joy_origin if _joy_id != -1 else _joy_default
	var knob := _joy_pos if _joy_id != -1 else base
	draw_circle(base, JOY_R, Color(1, 1, 1, 0.12))
	draw_arc(base, JOY_R, 0, TAU, 32, Color(1, 1, 1, 0.35), 3.0)
	draw_circle(base + (knob - base).limit_length(JOY_R), 38.0, Color(1, 1, 1, 0.3))
	draw_circle(_pause_pos, 36.0, Color(0, 0, 0, 0.35))
	draw_string(font, _pause_pos + Vector2(-36, 9), "II", HORIZONTAL_ALIGNMENT_CENTER, 72.0, 26)
	var held: Array = _btn_touch.values()
	for b in _buttons:
		var c: Vector2 = b["pos"]
		var r: float = b["r"]
		draw_circle(c, r, Color(1, 1, 1, 0.34 if held.has(b["id"]) else 0.16))
		draw_arc(c, r, 0, TAU, 32, Color(1, 1, 1, 0.5), 3.0)
		var lbl: String = b["label"]
		var stolen: bool = player != null and player.power_stolen
		if stolen and b["id"] == "power":
			lbl = "FCS"
		draw_string(font, c + Vector2(-r, 8), lbl, HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, 22)
		if stolen and b["id"] == "spin":
			draw_circle(c, r - 3.0, Color(0, 0, 0, 0.55))
			draw_line(c + Vector2(-r * 0.5, -r * 0.5), c + Vector2(r * 0.5, r * 0.5), Color(1, 0.3, 0.3), 5.0)
			draw_line(c + Vector2(-r * 0.5, r * 0.5), c + Vector2(r * 0.5, -r * 0.5), Color(1, 0.3, 0.3), 5.0)
		if player != null and b["cd"] != "":
			var f := player.cd_frac(b["cd"])
			if f > 0.0:
				draw_circle(c, r - 3.0, Color(0, 0, 0, 0.5))
				draw_arc(c, r - 4.0, -PI / 2.0, -PI / 2.0 + TAU * f, 32, Color(1, 0.8, 0.2, 0.9), 6.0)

## Left/right unsafe margins (notch / rounded corners) converted to viewport units.
func _insets() -> Vector2:
	var win := Vector2(DisplayServer.window_get_size())
	if win.x <= 0.0:
		return Vector2.ZERO
	var sa := DisplayServer.get_display_safe_area()
	var k := get_viewport_rect().size.x / win.x
	return Vector2(maxf(0.0, float(sa.position.x)) * k, maxf(0.0, win.x - float(sa.end.x)) * k)
