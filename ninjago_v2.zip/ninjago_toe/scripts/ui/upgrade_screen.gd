class_name UpgradeScreen
extends Control
## Skills, weapon, costumes, achievements, collection. Used from pause menu and main menu.

signal closed

const TABS := [["Skills", "المهارات"], ["Weapon", "السلاح"], ["Costumes", "الأزياء"],
	["Achievements", "الإنجازات"], ["Collection", "المقتنيات"]]

var player: Fighter
var content: VBoxContainer

func open(p) -> void:
	player = p
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var bg := ColorRect.new()
	bg.color = Color(0.03, 0.03, 0.08, 0.96)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var vb := VBoxContainer.new()
	vb.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	vb.offset_left = 30
	vb.offset_right = -30
	vb.offset_top = 16
	vb.offset_bottom = -16
	vb.add_theme_constant_override("separation", 8)
	add_child(vb)
	var tabs := HBoxContainer.new()
	tabs.add_theme_constant_override("separation", 6)
	vb.add_child(tabs)
	for i in TABS.size():
		var b := Button.new()
		b.text = Loc.pick(TABS[i])
		b.custom_minimum_size = Vector2(0, 56)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.add_theme_font_size_override("font_size", 22)
		b.pressed.connect(_show.bind(i))
		tabs.add_child(b)
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(sc)
	content = VBoxContainer.new()
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_theme_constant_override("separation", 8)
	sc.add_child(content)
	var close := Button.new()
	close.text = Loc.t("close")
	close.custom_minimum_size = Vector2(0, 60)
	close.add_theme_font_size_override("font_size", 26)
	close.pressed.connect(func(): closed.emit())
	vb.add_child(close)
	_show(0)

func _lbl(text: String, size := 24) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return l

func _row(text: String, btn_text: String, enabled: bool, cb: Callable) -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	row.add_child(_lbl(text))
	var b := Button.new()
	b.text = btn_text
	b.custom_minimum_size = Vector2(150, 60)
	b.add_theme_font_size_override("font_size", 24)
	b.disabled = not enabled
	b.pressed.connect(cb)
	row.add_child(b)
	content.add_child(row)

func _reapply() -> void:
	if player != null and is_instance_valid(player):
		SkillTree.apply(player)

func _show(i: int) -> void:
	for c in content.get_children():
		c.queue_free()
	match i:
		0:
			_skills()
		1:
			_weapon()
		2:
			_costumes()
		3:
			_achievements()
		4:
			_collection()

func _skills() -> void:
	content.add_child(_lbl(Loc.pick(["Skill points: %d   |   Level %d", "نقاط المهارة: %d   |   المستوى %d"]) % [GameState.skill_points, GameState.level], 30))
	for id in SkillTree.ORDER:
		var d: Dictionary = SkillTree.DATA[id]
		var r: Array = d["req"]
		var txt := "%s  %d/%d\n%s" % [Loc.pick(d["name"]), SkillTree.lvl(id), int(d["max"]), Loc.pick(d["desc"])]
		if str(r[0]) != "" and SkillTree.lvl(str(r[0])) < int(r[1]):
			txt += "\n" + Loc.pick(["Requires %s %d", "يتطلب %s %d"]) % [Loc.pick(SkillTree.DATA[str(r[0])]["name"]), int(r[1])]
		_row(txt, "+ (1)", SkillTree.can_buy(id), func():
			SkillTree.buy(id)
			_reapply()
			_show(0))
	_row(Loc.pick(["Reset all skills (free)", "إعادة توزيع المهارات (مجانًا)"]), "Reset", true, func():
		SkillTree.respec()
		_reapply()
		_show(0))

func _weapon() -> void:
	var lv := GameState.weapon_level
	var cost := 100 * (lv + 1)
	content.add_child(_lbl(Loc.pick(["Coins: %d", "العملات: %d"]) % GameState.coins, 30))
	var txt := Loc.pick(["Weapon level %d/5\n+10% damage per level", "مستوى السلاح %d/5\n+10% ضرر لكل مستوى"]) % lv
	_row(txt, "%d" % cost if lv < 5 else "MAX", lv < 5 and GameState.coins >= cost, func():
		GameState.add_coins(-cost)
		GameState.weapon_level += 1
		GameState.save_game()
		_reapply()
		_show(1))

func _costumes() -> void:
	for id in CostumeDB.ORDER:
		var d: Dictionary = CostumeDB.DATA[id]
		var ok := CostumeDB.unlocked(id)
		var txt := Loc.pick(d["name"]) + ("  *" if GameState.costume == id else "")
		if not ok:
			txt += "\n" + Loc.pick(d["how"])
		_row(txt, Loc.pick(["Equip", "ارتدِ"]) if ok else Loc.pick(["Locked", "مقفل"]), ok and GameState.costume != id, func():
			GameState.costume = id
			if id != "default":
				GameState.award("fashionista")
			GameState.save_game()
			if player != null and is_instance_valid(player):
				player.setup_costume()
			_show(2))

func _achievements() -> void:
	for id in AchievementDB.ORDER:
		var d: Dictionary = AchievementDB.DATA[id]
		var got := GameState.achievements.has(id)
		content.add_child(_lbl(("[x] " if got else "[ ] ") + Loc.pick(d["name"]) + " - " + Loc.pick(d["desc"])))

func _collection() -> void:
	content.add_child(_lbl(Loc.pick(["Coins: %d/20", "العملات: %d/20"]) % int(GameState.stats.get("coins_collected", 0)), 28))
	content.add_child(_lbl(Loc.pick(["Elemental relics: %d/12", "الآثار العنصرية: %d/12"]) % GameState.count_ids(100, 199), 28))
	content.add_child(_lbl(Loc.pick(["Scrolls: %d/6", "اللفائف: %d/6"]) % GameState.count_ids(200, 299), 28))
	content.add_child(_lbl(Loc.pick(["Areas discovered: %d/10", "المناطق المكتشفة: %d/10"]) % int(GameState.stats.get("zones", 0)), 28))
	content.add_child(_lbl(Loc.pick(["Side missions", "المهمات الجانبية"]), 30))
	var sq := [
		["sq_bricks", ["Lost Relics: find 6 relics (+1 skill point)", "الآثار المفقودة: اعثر على 6 آثار (+1 نقطة مهارة)"]],
		["sq_scrolls", ["Scroll Scholar: read 6 scrolls (+150 coins)", "عالِم اللفائف: اقرأ 6 لفائف (+150 عملة)"]],
		["sq_dummies", ["Arena Practice: destroy 10 practice dummies (+150 XP)", "تدريب الساحة: حطّم 10 دمى تدريب (+150 خبرة)"]],
	]
	for q in sq:
		var done: bool = GameState.flags.get(q[0], false)
		content.add_child(_lbl(("[x] " if done else "[ ] ") + Loc.pick(q[1])))
