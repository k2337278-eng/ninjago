class_name Chapters
extends Node
## Story beats for the whole campaign. Beat index == GameState.story_step checkpoint.
## All dialogue is ORIGINAL DRAFT text (not quotes from the show). Event ORDER and the
## named plot facts below must be verified against an episode guide (see docs/STORY_PLAN.md).
##
## Beats: 0 arrival | 1 walk+welcome | 2-3 matches | 4-7 rival chapter (duel, survival, race,
## skill) | 8-9 hidden secrets (puzzles, Warden boss) | 10-11 power theft + Skylor + first
## restore | 12-13 serpent ruins + Warlord + captures | 14-15 rescues + player power restore |
## 16-17 final tournament (round 1, champion boss) | 18-20 final battle + ending.

const CH_FIRST := [0, 1, 2, 4, 8, 10, 12, 14, 16, 18]
const CH_NAMES := [
	["The Invitation", "الدعوة"], ["Arrival at Chen's Island", "الوصول إلى جزيرة تشِن"],
	["The Tournament Begins", "بداية البطولة"], ["Elemental Rivals", "خصوم العناصر"],
	["Hidden Secrets", "الأسرار الخفية"], ["The Power Theft", "سرقة القوى"],
	["The Anacondrai Plan", "مخطط الأناكوندراي"], ["Rescue Missions", "مهمات الإنقاذ"],
	["The Final Tournament", "البطولة الأخيرة"], ["The Final Battle", "المعركة الأخيرة"]]

var isl: Node3D
var ids: Array = []

func L(en: String, ar: String) -> String:
	return en if Loc.lang == "en" else ar

func nm(id: String) -> String:
	return CharacterDB.name_of(id)

func A() -> String:
	return ids[0]

func B() -> String:
	return ids[1]

func C() -> String:
	return ids[2]

func D() -> String:
	return ids[3]

func pl() -> String:
	return isl.player.display_name

func chen_name() -> String:
	return L("Master Chen", "الماستر تشِن")

func narr() -> String:
	return Loc.t("narrator")

func spawn_for(step: int) -> Vector3:
	match step:
		0, 1:
			return Vector3(0, 0.2, 52)
		10:
			return Vector3(0, 0.2, 10)
		12, 13:
			return Vector3(-48, 0.2, -34)
		14:
			return Vector3(-40, 0.2, -10)
		15:
			return Vector3(38, 0.2, -6)
	return Vector3(0, 0.2, 16)

func _banner_ch(n: int) -> void:
	await isl.hud.banner(L("Chapter %d: ", "الفصل %d: ") % n + Loc.pick(CH_NAMES[n - 1]), 2.0)

func _log(label: String, pts: int) -> void:
	GameState.points += pts
	GameState.tournament_log.append("%s: +%d" % [label, pts])

func _dist(p: Vector3) -> float:
	return Vector2(isl.player.global_position.x - p.x, isl.player.global_position.z - p.z).length()

func _wait_near(p: Vector3, r: float) -> bool:
	while isl._alive() and _dist(p) > r:
		await get_tree().create_timer(0.25).timeout
	return isl._alive()

func _sigils() -> int:
	var n := 0
	for k in ["sigil_a", "sigil_b", "sigil_c"]:
		if isl.flag(k):
			n += 1
	return n

func _ring_pos(center: Vector3, r: float, i: int, n: int) -> Vector3:
	var a := TAU * i / float(n)
	return center + Vector3(cos(a) * r, 0.3, sin(a) * r)

# ------------------------------------------------------------------ driver ---
func run() -> void:
	ids = isl.others_ids()
	var beats: Array = [_b0, _b1, _b2, _b3, _b4, _b5, _b6, _b7, _b8, _b9, _b10,
		_b11, _b12, _b13, _b14, _b15, _b16, _b17, _b18, _b19, _b20]
	var step: int = GameState.story_step
	for i in beats.size():
		if step <= i:
			var ok = await beats[i].call()
			if not ok or not isl._alive():
				return
			isl._set_step(i + 1)
			step = i + 1
	await _free_roam()

func _free_roam() -> void:
	isl.hud.set_objective(L("The island is yours. Collect everything, or replay chapters from the main menu.",
		"الجزيرة لك. اجمع كل شيء، أو أعد الفصول من القائمة الرئيسية."))

# ------------------------------------------------------- chapters 1-3 -------
func _b0() -> bool:
	isl.chapter_start()
	await _banner_ch(1)
	await isl._arrival()
	await isl.finish_chapter(1, 120.0, false)
	return isl._alive()

func _b1() -> bool:
	isl.chapter_start()
	await _banner_ch(2)
	await isl._walk_to_arena()
	if not isl._alive():
		return false
	await isl._welcome()
	await isl.finish_chapter(2, 150.0, false)
	return isl._alive()

func _b2() -> bool:
	isl.chapter_start()
	await _banner_ch(3)
	return await isl._match(1)

func _b3() -> bool:
	if not await isl._match(2):
		return false
	await isl.finish_chapter(3, 200.0, true)
	return isl._alive()

# ------------------------------------------------ chapter 4: rivals ----------
func _b4() -> bool:
	isl.chapter_start()
	GameState.tournament_log.clear()
	await _banner_ch(4)
	var chen := chen_name()
	await isl.talk([
		[chen, L("The rival rounds begin! Elemental masters will now face one another.", "تبدأ جولات المنافسين! سيواجه أسياد العناصر بعضهم بعضًا.")],
		[chen, L("Points decide everything: duels, survival, speed and skill.", "النقاط تحسم كل شيء: المبارزة والبقاء والسرعة والمهارة.")],
		[pl(), L("Rival rounds, then. Let's see who we're up against.", "جولات المنافسين إذن. لنرَ من سنواجه.")],
	])
	var rid := "kai" if GameState.selected_char != "kai" else "jay"
	var rname := L("%s Rival", "منافس %s") % Loc.t("el_" + str(CharacterDB.DATA[rid]["element"]))
	isl.hud.set_objective(L("Defeat your elemental rival.", "اهزم منافسك العنصري."))
	await isl.hud.banner(rname, 1.4)
	var e = isl.spawn_enemy("rival:" + rid, Vector3(0, 0.3, -14))
	e.display_name = rname
	if not await isl.wait_enemies_dead([e]):
		return false
	GameState.award("rival_beaten")
	_log(L("Rival duel", "مبارزة المنافس"), 150)
	await isl.talk([[chen, L("Impressive. The next trial tests endurance.", "مثير للإعجاب. التجربة التالية تختبر التحمل.")]])
	return true

func _b5() -> bool:
	await isl.talk([[chen_name(), L("Survive! Outlast everything I send at you for 45 seconds.", "اصمد! انجُ من كل ما أرسله إليك لمدة 45 ثانية.")]])
	await isl.hud.banner(L("SURVIVE 45s", "اصمد 45 ث"), 1.5)
	var t := 45.0
	var spawn_t := 0.0
	var foes: Array = []
	while t > 0.0:
		await get_tree().create_timer(0.25).timeout
		if not isl._alive() or isl.player.state == Fighter.S.DEAD:
			return false
		t -= 0.25
		spawn_t -= 0.25
		foes = foes.filter(func(x): return is_instance_valid(x) and x.state != Fighter.S.DEAD)
		if spawn_t <= 0.0 and foes.size() < 4:
			spawn_t = 6.0
			foes.append(isl.spawn_enemy("grunt", _ring_pos(Vector3(0, 0, -6), 10.0, randi() % 8, 8)))
		isl.hud.set_objective(L("Survive: %d s", "اصمد: %d ث") % int(ceil(t)))
	isl.clear_enemies()
	GameState.award("survivor")
	_log(L("Survival", "البقاء"), 100)
	await isl.hud.banner(L("Survived!", "نجوت!"), 1.4)
	return true

func _b6() -> bool:
	await isl.talk([[chen_name(), L("Next, a race! Pass every checkpoint before time runs out.", "التالي سباق! اعبر كل نقاط التفتيش قبل انتهاء الوقت.")]])
	var pts: Array = [Vector3(10.7, 0, 12.6), Vector3(18.6, 0, 4.7), Vector3(21.5, 0, -6.0),
		Vector3(18.6, 0, -16.7), Vector3(0, 0, -6), Vector3(-18.6, 0, -16.7),
		Vector3(-21.5, 0, -6.0), Vector3(-18.6, 0, 4.7), Vector3(-10.7, 0, 12.6), Vector3(0, 0, 16)]
	while true:
		await isl.teleport_party(Vector3(0, 0.2, 16))
		if not isl._alive():
			return false
		var beacons: Array = []
		for p in pts:
			var bc: MeshInstance3D = isl.make_beacon(p, Color(1.0, 0.9, 0.2))
			bc.visible = false
			beacons.append(bc)
		beacons[0].visible = true
		isl.player.input_locked = true
		for n in [3, 2, 1]:
			await isl.hud.banner(str(n), 0.2)
		await isl.hud.banner(L("GO!", "انطلق!"), 0.3)
		isl.player.input_locked = false
		var t := 55.0
		var idx := 0
		while idx < pts.size() and t > 0.0:
			await get_tree().create_timer(0.1).timeout
			if not isl._alive():
				return false
			t -= 0.1
			if _dist(pts[idx]) < 3.2:
				beacons[idx].visible = false
				idx += 1
				Sfx.play("coin")
				if idx < pts.size():
					beacons[idx].visible = true
			isl.hud.set_objective(L("Race: checkpoint %d/%d - %d s", "السباق: نقطة %d/%d - %d ث") % [mini(idx + 1, pts.size()), pts.size(), int(ceil(t))])
		for bc in beacons:
			bc.queue_free()
		if idx >= pts.size():
			GameState.award("racer")
			_log(L("Race", "السباق"), 100 + int(t * 2.0))
			await isl.hud.banner(L("Finish!", "النهاية!"), 1.2)
			break
		await isl.hud.banner(L("Too slow! Try again.", "بطيء جدًا! حاول مرة أخرى."), 1.2)
	return true

func _b7() -> bool:
	await isl.talk([[chen_name(), L("Finally, precision. Destroy every target before time runs out.", "أخيرًا، الدقة. حطّم كل الأهداف قبل انتهاء الوقت.")]])
	while true:
		var targets: Array = []
		for k in 6:
			targets.append(isl.spawn_enemy("dummy", _ring_pos(Vector3(0, 0, -6), 8.0, k, 6)))
		await isl.hud.banner(L("DESTROY THE TARGETS", "حطّم الأهداف"), 1.4)
		var t := 40.0
		var left := targets.size()
		while t > 0.0 and left > 0:
			await get_tree().create_timer(0.25).timeout
			if not isl._alive() or isl.player.state == Fighter.S.DEAD:
				return false
			t -= 0.25
			left = 0
			for e in targets:
				if is_instance_valid(e) and e.state != Fighter.S.DEAD:
					left += 1
			isl.hud.set_objective(L("Targets left: %d - %d s", "الأهداف المتبقية: %d - %d ث") % [left, int(ceil(t))])
		if left == 0:
			GameState.award("sharpshooter")
			_log(L("Skill challenge", "تحدي المهارة"), 100 + int(t * 2.0))
			break
		isl.clear_enemies()
		await isl.hud.banner(L("Time's up! Try again.", "انتهى الوقت! حاول مرة أخرى."), 1.2)
	var lines: Array = GameState.tournament_log.duplicate()
	lines.append(L("Total points: %d", "مجموع النقاط: %d") % GameState.points)
	await isl.finish_chapter(4, 420.0, true, lines)
	return isl._alive()

# --------------------------------------- chapter 5: hidden secrets -----------
func _b8() -> bool:
	isl.chapter_start()
	await _banner_ch(5)
	await isl.talk([
		[nm(A()), L("The scrolls and the locals keep hinting at a hidden grotto on this island.", "اللفائف وأهل الجزيرة يلمّحون إلى كهف خفي في هذه الجزيرة.")],
		[pl(), L("Then let's find it. Sealed doors in the west ruins, a barricade by the temple, a cliff to the northeast...", "إذن لنجده. أبواب مغلقة في الأطلال الغربية، وحاجز قرب المعبد، وجرف في الشمال الشرقي...")],
		[nm(B()), L("Three sigils seal the grotto gate. Find them all. Press USE near puzzles; I can help with my element.", "ثلاثة أختام تغلق بوابة الكهف. اعثروا عليها كلها. اضغط USE قرب الألغاز؛ أستطيع المساعدة بعنصري.")],
	])
	var gate: Door = isl.grotto_gate
	while isl._alive() and not gate.opened:
		var n := _sigils()
		isl.hud.set_objective(L("Activate the three sigils (%d/3)", "فعّل الأختام الثلاثة (%d/3)") % n)
		if n >= 3:
			break
		await get_tree().create_timer(0.4).timeout
	if not isl._alive():
		return false
	if not gate.opened:
		isl._cutscene_begin()
		isl._cine_start(Vector3(26, 7, -44), gate.global_position + Vector3(0, 2, 0))
		await get_tree().create_timer(0.8).timeout
		gate.open()
		Effects.shake(gate, 0.4)
		await get_tree().create_timer(2.2).timeout
		isl._cutscene_end()
	return isl._alive()

func _b9() -> bool:
	isl.hud.set_objective(L("Enter the hidden grotto.", "ادخل الكهف الخفي."))
	if not await _wait_near(Vector3(38, 0, -58), 7.0):
		return false
	GameState.award("secret_finder")
	await isl.talk([
		[L("Ancient Voice", "صوت قديم"), L("Who disturbs the grotto?", "من يزعج الكهف؟")],
		[pl(), L("Stand ready! Something is waking up.", "كونوا مستعدين! هناك شيء يستيقظ.")],
	])
	var b = isl.spawn_boss("warden", Vector3(38, 0.3, -62))
	await isl.hud.banner(b.display_name, 1.6)
	isl.hud.set_objective(L("Defeat the Arena Warden. Strike when it is exhausted (glowing yellow).", "اهزم حارس الساحة. اضرب عندما يتعب (يتوهج بالأصفر)."))
	if not await isl.wait_enemies_dead([b]):
		return false
	isl.clear_enemies()
	GameState.award("warden_slayer")
	GameState.skill_points += 2
	_log(L("Arena Warden", "حارس الساحة"), 200)
	Sfx.play("win")
	await isl.hud.banner(L("Warden defeated! +2 skill points", "هُزم الحارس! +2 نقطة مهارة"), 2.0)
	await isl.talk([[nm(A()), L("That thing guarded this place for a reason. Take the relic, you earned it.", "هذا الكائن كان يحرس المكان لسبب. خذ الأثر، لقد استحققته.")]])
	await isl.finish_chapter(5, 900.0, true)
	return isl._alive()

# --------------------------------------------- chapter 6: power theft --------
func _b10() -> bool:
	isl.chapter_start()
	await _banner_ch(6)
	await isl.teleport_party(Vector3(0, 0.2, 10))
	isl._cutscene_begin()
	var chen := chen_name()
	isl._cine_start(Vector3(-6, 12, -26), Vector3(0, 10.5, -42))
	await isl.talk([
		[chen, L("You have done well. Better than I hoped.", "أحسنتم. أفضل مما توقعت.")],
		[chen, L("Your power is a gift... and this staff knows how to collect gifts.", "قوتكم هدية... وهذه العصا تعرف كيف تجمع الهدايا.")],
	])
	isl._cine_start(Vector3(0, 6, 22), Vector3(0, 1.5, -2))
	await get_tree().create_timer(0.6).timeout
	isl.steal_power(A())
	await get_tree().create_timer(0.6).timeout
	isl.steal_power(B())
	await get_tree().create_timer(1.2).timeout
	await isl.talk([
		[nm(A()), L("My power... it's gone!", "قوتي... اختفت!")],
		[nm(B()), L("The staff took it. I can't feel my element at all.", "العصا أخذتها. لا أشعر بعنصري إطلاقًا.")],
		[pl(), L("Chen! Give it back!", "تشِن! أعدها!")],
		[chen, L("The tournament continues. And so does the staff.", "البطولة مستمرة. وكذلك العصا.")],
	])
	isl._cutscene_end()
	return isl._alive()

func _b11() -> bool:
	if isl.comp_by_id("skylor") == null:
		isl.add_companion("skylor", isl.player.global_position + Vector3(4, 0.3, 6))
	await get_tree().create_timer(0.8).timeout
	var sk := nm("skylor")
	await isl.talk([
		[sk, L("Wait! I saw what the staff did. I know how it works.", "انتظروا! رأيت ما فعلته العصا. أعرف كيف تعمل.")],
		[sk, L("Stolen power is held in crystals. I can draw it back, but only if I'm close.", "القوة المسلوبة تُحفظ في بلورات. أستطيع سحبها، لكن بشرط أن أكون قريبة.")],
		[pl(), L("Then we'll get you there. Where is the nearest crystal?", "إذن سنوصلك إليها. أين أقرب بلورة؟")],
		[sk, L("The temple altar, to the east. Expect guards.", "مذبح المعبد في الشرق. توقعوا حراسًا.")],
	])
	var v: PowerVessel = isl.vessels["v1"]
	v.restore_id = A()
	v.set_active(true)
	v.used.connect(func(): isl.restore_power(v.restore_id))
	isl.hud.set_objective(L("Go to the temple altar.", "اذهب إلى مذبح المعبد."))
	if not await _wait_near(Vector3(48, 0, -6), 14.0):
		return false
	var foes: Array = []
	var kinds := ["guard", "guard", "grunt", "brute"]
	for i in kinds.size():
		foes.append(isl.spawn_enemy(kinds[i], _ring_pos(Vector3(48, 0, -6), 7.0, i, 4)))
	isl.hud.set_objective(L("Defeat the guards!", "اهزم الحراس!"))
	if not await isl.wait_enemies_dead(foes):
		return false
	isl.hud.set_objective(L("Use the crystal while Skylor is near.", "استخدم البلورة وسكايلور بالقرب."))
	while isl._alive() and GameState.powers_stolen.has(A()):
		await get_tree().create_timer(0.3).timeout
	v.set_active(false)
	await isl.talk([[nm(A()), L("I can feel it again. Thank you, Skylor!", "أشعر بها من جديد. شكرًا يا سكايلور!")]])
	await isl.finish_chapter(6, 600.0, true)
	return isl._alive()

# ------------------------------------------ chapter 7: Anacondrai plan -------
func _b12() -> bool:
	isl.chapter_start()
	await _banner_ch(7)
	var sk := nm("skylor")
	await isl.talk([
		[sk, L("The crystal readings point northwest, to ruins that aren't on any tournament map.", "قراءات البلورة تشير إلى الشمال الغربي، إلى أطلال ليست على أي خريطة للبطولة.")],
		[nm(B()), L("Then that's where the staff's power is going.", "إذن إلى هناك تذهب قوة العصا.")],
		[pl(), L("Carefully, everyone. We go in together.", "بحذر يا جماعة. سندخل معًا.")],
	])
	isl.hud.set_objective(L("Investigate the Serpent Ruins (northwest).", "افحص أطلال الثعابين (الشمال الغربي)."))
	var gate: Door = isl.ruins_gate
	while isl._alive() and not gate.opened and _dist(Vector3(-48, 0, -41)) > 9.0:
		await get_tree().create_timer(0.25).timeout
	if not isl._alive():
		return false
	if not gate.opened:
		gate.open()
		Effects.shake(gate, 0.4)
		await get_tree().create_timer(1.4).timeout
	var rc := Vector3(-48, 0, -52)
	if not await _wait_near(rc, 10.0):
		return false
	isl.steal_power(GameState.selected_char)
	await isl.talk([[narr(), L("A pulse of dark energy drains your elemental power! Serpents rise from the stones.", "نبضة من الطاقة المظلمة تسلب قوتك العنصرية! ثعابين تنهض من بين الحجارة.")]])
	var foes: Array = []
	for i in 3:
		foes.append(isl.spawn_enemy("serpent", _ring_pos(rc, 7.0, i, 3)))
	isl.hud.set_objective(L("Survive the ambush!", "انجُ من الكمين!"))
	if not await isl.wait_enemies_dead(foes):
		return false
	while isl._alive():
		var n := 0
		for i in 3:
			if isl.flag("tablet_%d" % i):
				n += 1
		isl.hud.set_objective(L("Read the three serpent tablets (%d/3)", "اقرأ الألواح الثلاثة (%d/3)") % n)
		if n >= 3:
			break
		await get_tree().create_timer(0.4).timeout
	if not isl._alive():
		return false
	await isl.talk([
		[sk, L("The tablets say the tournament feeds the staff, and the staff feeds something older.", "الألواح تقول إن البطولة تغذي العصا، والعصا تغذي شيئًا أقدم.")],
		[pl(), L("An Anacondrai plan... Chen isn't only collecting power. He's waking an army.", "مخطط الأناكوندراي... تشِن لا يجمع القوة فقط. إنه يوقظ جيشًا.")],
		[nm(B()), L("Then we stop it. Starting with whoever guards this place.", "إذن نوقفه. بدءًا بمن يحرس هذا المكان.")],
	])
	return true

func _b13() -> bool:
	var rc := Vector3(-48, 0, -52)
	var sk := nm("skylor")
	isl.hud.set_objective(L("Defeat the Anacondrai Warlord.", "اهزم قائد الأناكوندراي."))
	await isl.talk([[L("Anacondrai Warlord", "قائد الأناكوندراي"), L("You walk where the sleeping ones lie. Leave... or join them.", "تمشون حيث يرقد النائمون. ارحلوا... أو انضموا إليهم.")]])
	var b = isl.spawn_boss("warlord", rc + Vector3(0, 0.3, 0))
	await isl.hud.banner(b.display_name, 1.6)
	if not await isl.wait_enemies_dead([b]):
		return false
	isl.clear_enemies()
	GameState.award("warlord_slayer")
	GameState.skill_points += 2
	_log(L("Anacondrai Warlord", "قائد الأناكوندراي"), 300)
	await isl.hud.banner(L("Warlord defeated! +2 skill points", "هُزم القائد! +2 نقطة مهارة"), 2.0)
	var v2: PowerVessel = isl.vessels["v2"]
	v2.set_active(true)
	await isl.talk([[sk, L("Now, while the crystal is unguarded!", "الآن، والبلورة بلا حراسة!")]])
	await get_tree().create_timer(0.6).timeout
	v2.done = true
	isl.restore_power(B())
	await get_tree().create_timer(1.0).timeout
	v2.set_active(false)
	await isl.talk([[nm(B()), L("I can feel my element again!", "أشعر بعنصري من جديد!")]])
	isl._cutscene_begin()
	await isl.talk([[narr(), L("Chen's forces strike from the shadows and drag two of your friends away.", "قوات تشِن تهاجم من الظلال وتسحب اثنين من أصدقائك بعيدًا.")]])
	isl.remove_companion(C())
	await get_tree().create_timer(0.5).timeout
	isl.remove_companion(D())
	await get_tree().create_timer(0.8).timeout
	await isl.talk([
		[pl(), L("No! They took %s and %s!", "لا! لقد أخذوا %s و%s!") % [nm(C()), nm(D())]],
		[sk, L("They'll be held in cages around the island. We can still reach them.", "سيُحتجزون في أقفاص حول الجزيرة. ما زال بإمكاننا الوصول إليهم.")],
	])
	isl._cutscene_end()
	await isl.finish_chapter(7, 900.0, true)
	return isl._alive()

# ----------------------------------------------- chapter 8: rescues ----------
func _b14() -> bool:
	isl.chapter_start()
	await _banner_ch(8)
	var sk := nm("skylor")
	await isl.talk([[sk, L("Chen's guards hold them in cages. One is in the Whispering Cave.", "حراس تشِن يحتجزونهما في أقفاص. أحدهما في الكهف الهامس.")]])
	var cage: Door = isl.make_cage(Vector3(-53, 0, -8), C())
	isl.hud.set_objective(L("Rescue %s in the Whispering Cave.", "أنقذ %s في الكهف الهامس.") % nm(C()))
	if not await _wait_near(Vector3(-50, 0, -12), 12.0):
		return false
	var foes: Array = []
	var kinds := ["guard", "guard", "guard", "brute"]
	var spots := [Vector3(-48, 0.3, -10), Vector3(-48, 0.3, -15), Vector3(-45, 0.3, -12), Vector3(-46, 0.3, -8)]
	for i in kinds.size():
		foes.append(isl.spawn_enemy(kinds[i], spots[i]))
	isl.hud.set_objective(L("Defeat the cave guards!", "اهزم حراس الكهف!"))
	if not await isl.wait_enemies_dead(foes):
		return false
	cage.open()
	isl.free_captive(C())
	isl.add_companion(C(), Vector3(-52, 0.3, -9))
	await isl.talk([[nm(C()), L("About time! Thanks. Let's get the other one out.", "أخيرًا! شكرًا. لنُخرج الآخر.")]])
	return true

func _b15() -> bool:
	var sk := nm("skylor")
	var a_el := str(CharacterDB.DATA[A()]["element"])
	var cage: Door = isl.make_cage(Vector3(42, 0, -12), D())
	var lock := ElementTarget.new()
	lock.element = a_el
	lock.blocker_size = Vector3(3, 3, 0.6)
	lock.hit_radius = 3.0
	lock.position = Vector3(42, 1.5, -9.4)
	isl.add_child(lock)
	await isl.talk([[sk, L("The other cage is at the temple. Its lock is sealed with %s power. Ask %s to break it.", "القفص الآخر في المعبد. قفله مختوم بقوة %s. اطلب من %s كسره.") % [Loc.t("el_" + a_el), nm(A())]]])
	isl.hud.set_objective(L("Rescue %s at the temple.", "أنقذ %s في المعبد.") % nm(D()))
	if not await _wait_near(Vector3(42, 0, -10), 14.0):
		return false
	var foes: Array = []
	var kinds := ["serpent", "serpent", "serpent", "guard"]
	for i in kinds.size():
		foes.append(isl.spawn_enemy(kinds[i], _ring_pos(Vector3(42, 0, -6), 8.0, i, 4)))
	isl.hud.set_objective(L("Defeat the temple guards!", "اهزم حراس المعبد!"))
	if not await isl.wait_enemies_dead(foes):
		return false
	isl.hud.set_objective(L("Break the lock with %s power (USE near it).", "اكسر القفل بقوة %s (USE بقربه).") % Loc.t("el_" + a_el))
	while isl._alive() and not lock.done:
		await get_tree().create_timer(0.3).timeout
	if not isl._alive():
		return false
	cage.open()
	isl.free_captive(D())
	isl.add_companion(D(), Vector3(42, 0.3, -9))
	GameState.award("rescuer")
	await isl.talk([[nm(D()), L("Free at last! What did I miss?", "حرّ أخيرًا! ماذا فاتني؟")]])
	var pid := GameState.selected_char
	await isl.talk([[sk, L("Your own power is still trapped. The crystal in the cave, now!", "قوتك ما زالت محبوسة. البلورة في الكهف، الآن!")]])
	var v3: PowerVessel = isl.vessels["v3"]
	v3.restore_id = pid
	v3.set_active(true)
	v3.used.connect(func(): isl.restore_power(pid))
	isl.hud.set_objective(L("Go to the cave crystal with Skylor and restore your power.", "اذهب إلى بلورة الكهف مع سكايلور واستعد قوتك."))
	while isl._alive() and GameState.powers_stolen.has(pid):
		await get_tree().create_timer(0.3).timeout
	v3.set_active(false)
	await isl.talk([[pl(), L("My power is back. Chen, we're coming for you.", "عادت قوتي. تشِن، نحن قادمون إليك.")]])
	await isl.finish_chapter(8, 1000.0, true)
	return isl._alive()

# ------------------------------------------- chapter 9: final tournament -----
func _b16() -> bool:
	isl.chapter_start()
	GameState.tournament_log.clear()
	await _banner_ch(9)
	await isl.teleport_party(Vector3(0, 0.2, 10))
	await isl.talk([[chen_name(), L("The final tournament begins! Only the best remain standing.", "تبدأ البطولة الأخيرة! الأفضل فقط سيبقى واقفًا.")]])
	await isl.hud.banner(L("ROUND 1", "الجولة 1"), 1.4)
	var foes: Array = []
	var kinds := ["elite", "elite", "elite", "serpent", "serpent"]
	for i in kinds.size():
		foes.append(isl.spawn_enemy(kinds[i], _ring_pos(Vector3(0, 0, -6), 9.0, i, 5)))
	isl.hud.set_objective(L("Win round 1!", "اربح الجولة 1!"))
	if not await isl.wait_enemies_dead(foes):
		return false
	_log(L("Round 1", "الجولة 1"), 300)
	Sfx.play("win")
	await isl.hud.banner(L("Round 1 won!", "ربحت الجولة 1!"), 1.4)
	return true

func _b17() -> bool:
	var chen := chen_name()
	await isl.talk([[chen, L("Round two: the reigning Champion. Do try to keep up.", "الجولة الثانية: البطل الحالي. حاولوا مجاراته.")]])
	var b = isl.spawn_boss("champion", Vector3(0, 0.3, -14))
	await isl.hud.banner(b.display_name, 1.6)
	isl.hud.set_objective(L("Defeat the Tournament Champion.", "اهزم بطل البطولة."))
	if not await isl.wait_enemies_dead([b]):
		return false
	isl.clear_enemies()
	GameState.award("champion")
	GameState.skill_points += 2
	_log(L("Champion", "البطل"), 500)
	var lines: Array = GameState.tournament_log.duplicate()
	lines.append(L("Total points: %d", "مجموع النقاط: %d") % GameState.points)
	await isl.talk([[chen, L("You have won. But I never meant for anyone to keep the prize.", "لقد فزتم. لكنني لم أقصد أن يحتفظ أحد بالجائزة.")]])
	await isl.finish_chapter(9, 900.0, true, lines)
	return isl._alive()

# ------------------------------------------------ chapter 10: final battle ---
func _b18() -> bool:
	isl.chapter_start()
	await _banner_ch(10)
	await isl.teleport_party(Vector3(0, 0.2, 8))
	var sk := nm("skylor")
	await isl.talk([
		[sk, L("The staff holds everything he took. Break his guard, then strike when he is exhausted: he glows yellow.", "العصا تحوي كل ما أخذه. اكسروا دفاعه ثم اضربوه عندما يتعب: يتوهج بالأصفر.")],
		[nm(C()), L("And watch the ground. Red circles mean danger.", "وانتبهوا للأرض. الدوائر الحمراء تعني الخطر.")],
		[pl(), L("Together, then. For everyone he hurt.", "معًا إذن. من أجل كل من آذاهم.")],
	])
	isl.hud.toast(L("Tip: spend skill points in Pause > Upgrades.", "نصيحة: أنفق نقاط المهارة من الإيقاف المؤقت > الترقيات."))
	return isl._alive()

func _b19() -> bool:
	isl.chen.visible = false
	var chen := chen_name()
	await isl.talk([[chen, L("Enough games. The staff will take everything you have left.", "كفى ألعابًا. العصا ستأخذ كل ما تبقى لكم.")]])
	var b = isl.spawn_boss("chen", Vector3(0, 0.3, -16))
	await isl.hud.banner(b.display_name, 1.8)
	isl.hud.set_objective(L("Defeat Master Chen!", "اهزم الماستر تشِن!"))
	if not await isl.wait_enemies_dead([b]):
		return false
	isl.clear_enemies()
	GameState.skill_points += 3
	_log(L("Master Chen", "الماستر تشِن"), 1000)
	await isl.hud.banner(L("Master Chen defeated!", "هُزم الماستر تشِن!"), 2.0)
	return true

func _b20() -> bool:
	isl._cutscene_begin()
	GameState.award("chen_defeated")
	var sk := nm("skylor")
	await isl.talk([
		[sk, L("The staff's power is breaking apart. It's over.", "قوة العصا تتفكك. لقد انتهى الأمر.")],
		[nm(A()), L("We did it. Together.", "فعلناها. معًا.")],
		[nm(B()), L("I'd say that was one memorable tournament.", "أقول إنها كانت بطولة لا تُنسى.")],
		[nm(C()), L("Let's never do that again.", "لنَعِد ألا نكررها أبدًا.")],
		[nm(D()), L("Agreed. Though the noodles were good.", "متفق. مع أن النودلز كانت لذيذة.")],
		[pl(), L("The island is quiet at last. Let's go home.", "الجزيرة هادئة أخيرًا. لنعد إلى الديار.")],
		[narr(), L("And so the Tournament of Elements came to an end.", "وهكذا انتهت بطولة العناصر.")],
	])
	await isl.hud.banner(L("THE END", "النهاية"), 3.0)
	GameState.chapter_done = true
	await isl.finish_chapter(10, 1200.0, true, [L("Thank you for playing!", "شكرًا للعب!"), L("Total points: %d", "مجموع النقاط: %d") % GameState.points])
	isl._cutscene_end()
	return isl._alive()
