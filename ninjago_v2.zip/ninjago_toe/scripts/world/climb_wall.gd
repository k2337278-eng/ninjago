class_name ClimbWall
extends Area3D
## Climbable surface: while a fighter is inside and pushes the stick, it climbs.
## On leaving the top it hops toward top_dir so it lands on the ledge.

var size := Vector3(4, 8, 1.8)
var top_dir := Vector3(0, 0, -1)

func _ready() -> void:
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = size
	cs.shape = bs
	add_child(cs)
	var vines := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(size.x * 0.9, size.y, 0.08)
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.15, 0.4, 0.15)
	bm.material = m
	vines.mesh = bm
	vines.position = -top_dir * (size.z * 0.5 - 0.1)
	vines.rotation.y = 0.0 if absf(top_dir.z) > 0.5 else PI / 2.0
	add_child(vines)
	body_entered.connect(_on_enter)
	body_exited.connect(_on_exit)

func _on_enter(b: Node3D) -> void:
	var f := b as Fighter
	if f != null:
		f.climb_zones += 1

func _on_exit(b: Node3D) -> void:
	var f := b as Fighter
	if f == null:
		return
	f.climb_zones = maxi(0, f.climb_zones - 1)
	if f.velocity.y > 0.0:
		f.velocity.y = 6.0
		f.knock = top_dir.normalized() * 12.0
