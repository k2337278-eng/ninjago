class_name Interactable
extends Node3D
## Anything the USE button can act on. Island picks the nearest usable one.

var prompt: Array = ["Use", "استخدم"]
var radius := 2.5

func _ready() -> void:
	add_to_group("interactable")

func can_use(_p: Player) -> bool:
	return true

func prompt_text() -> String:
	return Loc.pick(prompt)

func use(_p: Player) -> void:
	pass
