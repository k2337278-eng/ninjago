class_name IslandExtras
extends RefCounted
## Extra island content built on top of the base world: puzzles, climbing, hidden areas,
## shrines, serpent ruins, NPCs, scrolls, relics, practice dummies, decoration.

const ROCK := Color(0.42, 0.4, 0.4)

static func build(isl) -> void:
	_decor(isl)
	_ruins_puzzle(isl)
	_fire_gate(isl)
	_cliff(isl)
	_temple_roof(isl)
	_grotto(isl)
	_serpent_ruins(isl)
	_shrines(isl)
	_vessels(isl)
	_npcs(isl)
	_scrolls_and_relics(isl)
	_practice(isl)
	_staff(isl)
	_flames(isl)

static func _decor(isl) -> void:
	for i in 6:
		var z := 14.0 + i * 5.5
		for sx in [-3.4, 3.4]:
			isl._cylinder(Vector3(sx, 1.1, z), 0.08, 0.1, 2.2, Color(0.3, 0.2, 0.1), false)
			isl._block(Vector3(sx, 2.35, z), Vector3(0.35, 0.35, 0.35), Color(1.0, 0.8, 0.4), false, true)
	for i in 5:
		isl._cylinder(Vector3(-6.0 + i * 1.1, 0.5, 58.0 - (i % 2) * 1.2), 0.45, 0.45, 1.0, Color(0.5, 0.32, 0.15))

# ---- Sigil A: push a crate onto the plate -> door opens -> lever -------------
static func _ruins_puzzle(isl) -> void:
	var cx := -30.0
	isl._block(Vector3(cx - 4.5, 2, 11), Vector3(1, 4, 6), ROCK)
	isl._block(Vector3(cx + 4.5, 2, 11), Vector3(1, 4, 6), ROCK)
	isl._block(Vector3(cx, 2, 8), Vector3(10, 4, 1), ROCK)
	var door := Door.new()
	door.size = Vector3(8, 4, 1)
	door.color = Color(0.35, 0.3, 0.28)
	door.flag_id = "door_ruins"
	door.position = Vector3(cx, 2, 14)
	isl.add_child(door)
	var plate := PressurePlate.new()
	plate.flag_id = "plate_ruins"
	plate.position = Vector3(cx, 0, 19)
	plate.changed.connect(func(p: bool):
		if p:
			door.open())
	isl.add_child(plate)
	for cp in [Vector3(cx, 0.7, 26), Vector3(cx - 6, 0.7, 23)]:
		var c := Crate.new()
		c.position = cp
		isl.add_child(c)
	var lever := Lever.new()
	lever.flag_id = "sigil_a"
	lever.position = Vector3(cx, 0, 10)
	isl.add_child(lever)
	isl.add_relic(Vector3(cx + 2.5, 1.0, 10), 105)
	for p in [Vector3(cx - 9, 1.5, 20), Vector3(cx + 9, 1.0, 22), Vector3(cx - 9, 1.2, 29), Vector3(cx + 8, 1.5, 15)]:
		isl._cylinder(p, 0.6, 0.7, 3.0 if p.y > 1.2 else 2.0, Color(0.6, 0.58, 0.55))

# ---- Sigil B: burn the barricade (fire power) --------------------------------
static func _fire_gate(isl) -> void:
	isl._block(Vector3(62, 2, -11.5), Vector3(11, 4, 1), ROCK)
	isl._block(Vector3(62, 2, -0.5), Vector3(11, 4, 1), ROCK)
	isl._block(Vector3(67.5, 2, -6), Vector3(1, 4, 11), ROCK)
	var t := ElementTarget.new()
	t.element = "fire"
	t.flag_id = "gate_fire"
	t.blocker_size = Vector3(1, 4, 10)
	t.hit_radius = 3.5
	t.position = Vector3(56.5, 2, -6)
	isl.add_child(t)
	var lever := Lever.new()
	lever.flag_id = "sigil_b"
	lever.position = Vector3(64.5, 0, -6)
	isl.add_child(lever)
	isl.add_relic(Vector3(65, 1.0, -9), 106)

# ---- Sigil C: climb the cliff -------------------------------------------------
static func _cliff(isl) -> void:
	isl._block(Vector3(58, 6, -40), Vector3(14, 12, 14), Color(0.4, 0.37, 0.35))
	var cw := ClimbWall.new()
	cw.size = Vector3(8, 11.7, 1.8)
	cw.top_dir = Vector3(0, 0, -1)
	cw.position = Vector3(58, 5.85, -32.1)
	isl.add_child(cw)
	var lever := Lever.new()
	lever.flag_id = "sigil_c"
	lever.position = Vector3(58, 12.0, -40)
	isl.add_child(lever)
	isl.add_relic(Vector3(62, 12.9, -44), 107)

static func _temple_roof(isl) -> void:
	isl._wall(Vector3(48, 6.5, -6), Vector3(18, 1, 18))
	var cw := ClimbWall.new()
	cw.size = Vector3(4, 6.7, 1.8)
	cw.top_dir = Vector3(0, 0, 1)
	cw.position = Vector3(48, 3.35, -15.9)
	isl.add_child(cw)
	isl.add_relic(Vector3(48, 7.6, -12), 111)

# ---- Hidden Grotto (Arena Warden boss) -----------------------------------------
static func _grotto(isl) -> void:
	var c := Vector3(38, 0, -58)
	for i in 14:
		var a := TAU * i / 14.0
		if sin(a) > 0.95:
			continue
		isl._block(Vector3(c.x + cos(a) * 10.0, 2.5, c.z + sin(a) * 10.0), Vector3(4.8, 5, 1), ROCK, true, false, -a - PI / 2.0)
	var gate := Door.new()
	gate.size = Vector3(9.2, 5, 1)
	gate.color = Color(0.3, 0.28, 0.3)
	gate.flag_id = "gate_grotto"
	gate.position = Vector3(c.x, 2.5, c.z + 10.0)
	isl.add_child(gate)
	isl.grotto_gate = gate
	isl._cylinder(Vector3(c.x, 0.02, c.z), 9.8, 9.8, 0.04, Color(0.12, 0.1, 0.15), false)
	for i in 6:
		var a := TAU * i / 6.0 + 0.3
		var p := Vector3(c.x + cos(a) * 8.0, 0, c.z + sin(a) * 8.0)
		isl._cylinder(p + Vector3(0, 1.0, 0), 0.1, 0.12, 2.0, Color(0.3, 0.2, 0.1), false)
		isl._block(p + Vector3(0, 2.2, 0), Vector3(0.4, 0.4, 0.4), Color(0.4, 0.9, 1.0), false, true)
	isl.add_relic(Vector3(c.x, 1.0, c.z - 7), 108)

# ---- Serpent Ruins (Anacondrai) -------------------------------------------------
static func _serpent_ruins(isl) -> void:
	var c := Vector3(-48, 0, -52)
	var purple := Color(0.3, 0.2, 0.4)
	isl._block(Vector3(c.x, 2.5, -66), Vector3(28, 5, 1), purple)
	isl._block(Vector3(-62, 2.5, -53.5), Vector3(1, 5, 25), purple)
	isl._block(Vector3(-34, 2.5, -53.5), Vector3(1, 5, 25), purple)
	isl._block(Vector3(-57.5, 2.5, -41), Vector3(9, 5, 1), purple)
	isl._block(Vector3(-38.5, 2.5, -41), Vector3(9, 5, 1), purple)
	var gate := Door.new()
	gate.size = Vector3(10, 5, 1)
	gate.color = Color(0.2, 0.12, 0.28)
	gate.flag_id = "gate_ruins"
	gate.position = Vector3(c.x, 2.5, -41)
	isl.add_child(gate)
	isl.ruins_gate = gate
	isl._cylinder(Vector3(c.x, 0.03, c.z), 7.0, 7.0, 0.05, Color(0.45, 0.15, 0.7), false)
	for i in 8:
		var a := TAU * i / 8.0
		var h := 3.0 + (i % 3) * 1.5
		isl._cylinder(Vector3(c.x + cos(a) * 9.0, h * 0.5, c.z + sin(a) * 9.0), 0.7, 0.8, h, purple)
	for i in 5:
		isl._cylinder(Vector3(-56, 0.3 + i * 0.6, -60), 1.2 - i * 0.2, 1.4 - i * 0.2, 0.6, Color(0.25, 0.45, 0.2), false)
	var tab := [Vector3(-56, 0, -47), Vector3(-40, 0, -47), Vector3(-48, 0, -61)]
	var texts := [
		[["The old serpents were sealed away, but never forgotten.", "الثعابين القديمة حُبست، لكنها لم تُنسَ."]],
		[["The tournament is no game. It gathers power for the staff.", "البطولة ليست لعبة. إنها تجمع القوة للعصا."]],
		[["When the staff is full, the sleeping army will wake.", "عندما تمتلئ العصا، سيستيقظ الجيش النائم."]],
	]
	for i in 3:
		var s := LoreScroll.new()
		s.counts = false
		s.flag_id = "tablet_%d" % i
		s.title = ["Serpent Tablet", "لوح الثعابين"]
		s.text = texts[i][0]
		s.isl = isl
		s.position = tab[i]
		isl.add_child(s)
	isl.add_relic(Vector3(-58, 1.0, -63), 109)

# ---- Elemental shrines (5 optional relics) ---------------------------------------
static func _shrines(isl) -> void:
	for i in 5:
		var x := 18.0 + 5.5 * i
		var el: String = CharacterDB.ORDER[i]
		isl._block(Vector3(x, 1.5, 23.2), Vector3(3.4, 3, 0.6), ROCK)
		isl._block(Vector3(x - 1.8, 1.5, 25), Vector3(0.6, 3, 3.4), ROCK)
		isl._block(Vector3(x + 1.8, 1.5, 25), Vector3(0.6, 3, 3.4), ROCK)
		var t := ElementTarget.new()
		t.element = el
		t.flag_id = "shrine_" + el
		t.blocker_size = Vector3(3, 3, 0.6)
		t.position = Vector3(x, 1.5, 26.8)
		isl.add_child(t)
		isl.add_relic(Vector3(x, 1.0, 25), 100 + i)

static func _vessels(isl) -> void:
	var spots := {"v1": Vector3(48, 1.2, -6), "v2": Vector3(-48, 0, -63), "v3": Vector3(-55, 0, -12)}
	for k in spots.keys():
		var v := PowerVessel.new()
		v.position = spots[k]
		isl.add_child(v)
		isl.vessels[k] = v

static func _npc(isl, pos: Vector3, speaker: Array, cfg: Dictionary, phases: Array) -> void:
	var n := Npc.new()
	n.isl = isl
	n.speaker = speaker
	n.cfg = cfg
	n.phases = phases
	n.position = pos
	isl.add_child(n)

static func _npcs(isl) -> void:
	_npc(isl, Vector3(14, 0, 56), ["Old Fisherman", "الصياد العجوز"],
		{"suit": Color(0.2, 0.4, 0.6), "style": "bare", "hair": Color(0.8, 0.8, 0.8)},
		[{"until": 9, "lines": [
			["The sea was calm until the invitations went out. Now every boat brings a stranger.", "كان البحر هادئًا حتى أُرسلت الدعوات. الآن كل قارب يحمل غريبًا."],
			["Mind the arena. Chen likes a good show.", "احذر الساحة. تشِن يحب العروض الكبيرة."]]},
		{"until": 99, "lines": [
			["I've seen strange lights over the palace at night. Be careful, friend.", "رأيت أضواءً غريبة فوق القصر ليلًا. احذر يا صديقي."]]}])
	_npc(isl, Vector3(5, 0, 13), ["Arena Guard", "حارس الساحة"],
		{"suit": Color(0.4, 0.4, 0.45), "style": "bare", "hair": Color(0.1, 0.1, 0.1)},
		[{"until": 3, "lines": [["Contenders only past this point. Good luck.", "للمتنافسين فقط بعد هذه النقطة. بالتوفيق."]]},
		{"until": 99, "lines": [["Matches are more serious than they look. Keep your guard up.", "المباريات أخطر مما تبدو. ابقَ متيقظًا."]]}])
	_npc(isl, Vector3(9, 0, -40), ["Palace Attendant", "خادم القصر"],
		{"suit": Color(0.5, 0.2, 0.3), "style": "bare", "hair": Color(0.2, 0.15, 0.1)},
		[{"until": 9, "lines": [["The master watches every match from his balcony.", "السيد يراقب كل مباراة من شرفته."]]},
		{"until": 99, "lines": [["I don't know what the master is planning... but the staff hums at night.", "لا أعرف ما يخطط له السيد... لكن العصا تطنّ ليلًا."]]}])
	_npc(isl, Vector3(44, 0, 2), ["Temple Monk", "راهب المعبد"],
		{"suit": Color(0.9, 0.5, 0.1), "style": "bare", "hair": Color(0.1, 0.1, 0.1)},
		[{"until": 9, "lines": [
			["The shrines along the eastern path answer to the five elements. Ask the right ninja for help.", "المزارات على الطريق الشرقي تستجيب للعناصر الخمسة. اطلب المساعدة من النينجا المناسب."]]},
		{"until": 99, "lines": [["Powers taken can be returned, if one knows how to draw them back.", "القوى المسلوبة يمكن أن تعود، إن عُرف كيف تُسحب."]]}])
	_npc(isl, Vector3(-46, 0, -9), ["Cave Hermit", "ناسك الكهف"],
		{"suit": Color(0.35, 0.3, 0.25), "style": "bare", "hair": Color(0.7, 0.7, 0.7)},
		[{"until": 9, "lines": [["Hidden places hold hidden things: sealed doors, burnable barricades, cliffs with a ledge.", "الأماكن الخفية تخبئ أشياء خفية: أبواب مغلقة وحواجز تحترق وجروف لها حافة."]]},
		{"until": 99, "lines": [["Dark things move in the ruins to the northwest.", "أشياء مظلمة تتحرك في الأطلال إلى الشمال الغربي."]]}])
	_npc(isl, Vector3(22, 0, -30), ["Forest Scout", "كشّاف الغابة"],
		{"suit": Color(0.2, 0.45, 0.2), "style": "bare", "hair": Color(0.3, 0.2, 0.1)},
		[{"until": 9, "lines": [["There's a cliff to the northeast with a ledge on top. You'd have to climb it.", "هناك جرف في الشمال الشرقي وعلى قمته حافة. عليك أن تتسلقه."]]},
		{"until": 99, "lines": [["Stay clear of the ruins. Serpent-like shapes patrol there.", "ابتعد عن الأطلال. أشكال تشبه الثعابين تحرسها."]]}])
	_npc(isl, Vector3(-26, 0, 19), ["Ruins Scholar", "باحث الأطلال"],
		{"suit": Color(0.5, 0.45, 0.2), "style": "bare", "hair": Color(0.15, 0.1, 0.05)},
		[{"until": 9, "lines": [["A plate, some crates, a sealed door... Try pushing a crate onto the plate.", "لوح ضغط وصناديق وباب مغلق... جرّب دفع صندوق فوق اللوح."]]},
		{"until": 99, "lines": [["These ruins hold more secrets than they let on.", "هذه الأطلال تخفي أسرارًا أكثر مما تُظهر."]]}])

static func scroll_defs() -> Array:
	return [
		[Vector3(8, 0, 58), ["Sailor's Note", "ملاحظة بحّار"], ["The tournament was announced far and wide. Many came; few asked who paid for the arena.", "أُعلنت البطولة في كل مكان. جاء كثيرون؛ وقلّما سأل أحد من دفع ثمن الساحة."]],
		[Vector3(12, 0, -18), ["Arena Ledger", "سجل الساحة"], ["Matches are scored by points: rival rounds, survival, a race and skill tests.", "تُحتسب المباريات بالنقاط: جولات المنافسين والبقاء وسباق واختبارات المهارة."]],
		[Vector3(-8, 0, -40), ["Palace Memo", "مذكرة القصر"], ["A staff is kept in the master's chambers. Tell no one about the staff.", "تُحفظ عصا في غرف السيد. لا تخبر أحدًا عن العصا."]],
		[Vector3(46, 0, -2), ["Temple Verse", "نشيد المعبد"], ["Five elements, five shrines, five friends. When one is silent, ask another.", "خمسة عناصر، خمسة مزارات، خمسة أصدقاء. إذا صمت أحدهم فاسأل غيره."]],
		[Vector3(-50, 0, -14), ["Hermit's Diary", "يوميات الناسك"], ["The crystals hum when a stolen power is near. One who draws power may draw it back.", "تطنّ البلورات عندما تقترب قوة مسلوبة. ومن يسحب القوة قد يعيدها."]],
		[Vector3(-44, 0, -50), ["Torn Page", "صفحة ممزقة"], ["Beneath the ruins sleeps an old army. The tournament feeds the staff.", "تحت الأطلال ينام جيش قديم. والبطولة تغذي العصا."]],
	]

static func _scrolls_and_relics(isl) -> void:
	var defs := scroll_defs()
	for i in defs.size():
		var s := LoreScroll.new()
		s.scroll_id = 200 + i
		s.title = defs[i][1]
		s.text = defs[i][2]
		s.isl = isl
		s.position = defs[i][0]
		isl.add_child(s)
	isl.add_relic(Vector3(-20, 1.0, 62), 110)

static func _practice(isl) -> void:
	for p in [Vector3(-16, 0.3, 46), Vector3(16, 0.3, 46), Vector3(-20, 0.3, 40), Vector3(20, 0.3, 40),
			Vector3(-24, 0.3, 50), Vector3(24, 0.3, 50), Vector3(-28, 0.3, 44), Vector3(28, 0.3, 44)]:
		var e = isl.spawn_enemy("dummy", p)
		e.add_to_group("practice")

static func _staff(isl) -> void:
	var staff := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.04
	cm.bottom_radius = 0.05
	cm.height = 1.8
	cm.radial_segments = 6
	cm.rings = 1
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.25, 0.1, 0.3)
	cm.material = m
	staff.mesh = cm
	staff.position = Vector3(0, -0.5, -0.1)
	isl.chen.arm_r.add_child(staff)
	var orb := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.14
	sm.height = 0.28
	sm.radial_segments = 8
	sm.rings = 4
	var om := StandardMaterial3D.new()
	om.albedo_color = Color(0.7, 0.2, 0.9)
	om.emission_enabled = true
	om.emission = Color(0.7, 0.2, 0.9)
	sm.material = om
	orb.mesh = sm
	orb.position = Vector3(0, 0.45, -0.1)
	isl.chen.arm_r.add_child(orb)

## Flame particles on arena pillar torches (6 on Medium, 12 on High, none on Low).
static func _flames(isl) -> void:
	var q := int(GameState.settings.get("quality", 1))
	if q == 0:
		return
	var n := 6 if q == 1 else 12
	for i in n:
		var a := TAU * i / float(n)
		var f := CPUParticles3D.new()
		var sm := SphereMesh.new()
		sm.radius = 0.12
		sm.height = 0.24
		sm.radial_segments = 6
		sm.rings = 3
		var mat := StandardMaterial3D.new()
		mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		mat.albedo_color = Color(1.0, 0.55, 0.1)
		sm.material = mat
		f.mesh = sm
		f.amount = 8
		f.lifetime = 0.9
		f.direction = Vector3.UP
		f.spread = 15.0
		f.initial_velocity_min = 0.8
		f.initial_velocity_max = 1.5
		f.gravity = Vector3(0, 0.5, 0)
		f.position = Vector3(cos(a) * 19.0, 6.9, -6.0 + sin(a) * 19.0)
		isl.add_child(f)
