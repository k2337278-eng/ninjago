class_name Lever
extends Interactable

signal activated

var flag_id := ""
var on := false
var one_shot := true
var pivot: Node3D
var orb_mat: StandardMaterial3D

func _ready() -> void:
	super()
	prompt = ["Pull the lever", "اسحب الذراع"]
	radius = 2.6
	var base := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.7, 0.5, 0.7)
	var bmat := StandardMaterial3D.new()
	bmat.albedo_color = Color(0.45, 0.43, 0.42)
	base.mesh = bm
	base.material_override = bmat
	base.position.y = 0.25
	add_child(base)
	pivot = Node3D.new()
	pivot.position.y = 0.5
	add_child(pivot)
	var hm := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.06
	cm.bottom_radius = 0.06
	cm.height = 1.0
	cm.radial_segments = 6
	cm.rings = 1
	var hmat := StandardMaterial3D.new()
	hmat.albedo_color = Color(0.35, 0.22, 0.1)
	hm.mesh = cm
	hm.material_override = hmat
	hm.position.y = 0.5
	pivot.add_child(hm)
	var orb := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.16
	sm.height = 0.32
	sm.radial_segments = 8
	sm.rings = 4
	orb_mat = StandardMaterial3D.new()
	orb_mat.emission_enabled = true
	sm.material = orb_mat
	orb.mesh = sm
	orb.position.y = 1.05
	pivot.add_child(orb)
	_apply_visual()
	if flag_id != "" and GameState.flags.get(flag_id, false):
		on = true
		_apply_visual()

func _apply_visual() -> void:
	pivot.rotation.z = 0.7 if on else -0.7
	var c := Color(0.2, 1.0, 0.3) if on else Color(1.0, 0.2, 0.2)
	orb_mat.albedo_color = c
	orb_mat.emission = c

func can_use(_p: Player) -> bool:
	return not (one_shot and on)

func use(_p: Player) -> void:
	if on and one_shot:
		return
	on = true
	_apply_visual()
	if flag_id != "":
		GameState.flags[flag_id] = true
		GameState.save_game()
	Sfx.play("ui")
	activated.emit()
