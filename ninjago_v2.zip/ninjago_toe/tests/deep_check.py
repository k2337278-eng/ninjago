#!/usr/bin/env python3
"""Deeper STATIC heuristics for GDScript (NOT a compiler; Godot was unavailable).
Checks: indentation structure, cross-class method existence, `:=` inferred from Variant-returning
calls, `%` format arg counts, signal/method names passed to connect(), await in non-coroutine
lambdas (info)."""
import os, re, sys
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
files = []
for d, _, fs in os.walk(root):
    for f in fs:
        if f.endswith(".gd"):
            files.append(os.path.join(d, f))
src = {p: open(p, encoding="utf-8").read() for p in files}
errs, warns = [], []
funcs_by_class, all_funcs, classes = {}, set(), {}
for p, t in src.items():
    m = re.search(r"^class_name (\w+)", t, re.M)
    fs = set(re.findall(r"^\s*(?:static )?func (\w+)\(", t, re.M))
    fs |= set(re.findall(r"^signal (\w+)", t, re.M))
    fs |= set(re.findall(r"^(?:var|const) (\w+)", t, re.M))
    base = re.search(r"^extends (\w+)", t, re.M)
    if m:
        classes[m.group(1)] = (p, base.group(1) if base else None)
        funcs_by_class[m.group(1)] = fs
    all_funcs |= fs
def inherited(cls):
    out = set(); c = cls
    while c in funcs_by_class:
        out |= funcs_by_class[c]; c = classes[c][1]
    return out
# 1. indentation
for p, t in src.items():
    rel = os.path.relpath(p, root); prev_indent = 0; prev_colon = False; depth = 0; cont = False
    for i, line in enumerate(t.split("\n"), 1):
        s = line.strip()
        if not s or s.startswith("#"): continue
        if cont:
            cont = False
            continue
        ind = len(line) - len(line.lstrip("\t"))
        if depth == 0:
            if prev_colon and ind != prev_indent + 1:
                errs.append(f"{rel}:{i} indent after ':' should be +1 (got {ind-prev_indent})")
            elif not prev_colon and ind > prev_indent:
                errs.append(f"{rel}:{i} unexpected indent")
            prev_indent = ind
            code = re.sub(r'"(\\.|[^"\\])*"', '""', s); code = re.sub(r"#.*", "", code).rstrip()
            prev_colon = code.endswith(":") and not code.endswith("::")
        stripped = re.sub(r'"(\\.|[^"\\])*"', '""', line); stripped = re.sub(r"#.*", "", stripped)
        depth += sum(stripped.count(c) for c in "([{") - sum(stripped.count(c) for c in ")]}")
        if depth < 0: depth = 0
        if depth > 0: prev_colon = False
        if line.rstrip().endswith("\\"):
            cont = True; prev_colon = False
        if depth > 0 and stripped.rstrip().endswith("\\"): pass
# 2. cross-class method existence
for p, t in src.items():
    rel = os.path.relpath(p, root)
    for m in re.finditer(r"\b([A-Z]\w+)\.(\w+)\(", t):
        c, f = m.groups()
        if c in funcs_by_class and f not in inherited(c) and f not in ("new",):
            errs.append(f"{rel}: {c}.{f}() not defined in {c} (or ancestors)")
    for m in re.finditer(r"\b(?:GameState|Loc|Sfx)\.(\w+)\(", t):
        pass
for auto, path in (("GameState","scripts/autoload/game_state.gd"),("Loc","scripts/autoload/loc.gd"),("Sfx","scripts/autoload/sfx.gd")):
    fs = set(re.findall(r"^\s*func (\w+)\(", open(os.path.join(root,path),encoding="utf-8").read(), re.M))
    for p, t in src.items():
        for m in re.finditer(r"\b%s\.(\w+)\(" % auto, t):
            if m.group(1) not in fs and m.group(1) not in ("connect","emit"):
                errs.append(f"{os.path.relpath(p, root)}: {auto}.{m.group(1)}() undefined")
# isl./story./hud. dynamic calls
targets = {"isl": ["Island","island"], "hud": ["Hud"], "story": ["Chapters"]}
island_f = set(re.findall(r"^\s*func (\w+)\(", src[os.path.join(root,"scripts/world/island.gd")], re.M))
for p, t in src.items():
    rel = os.path.relpath(p, root)
    for m in re.finditer(r"\bisl\.(\w+)\(", t):
        if m.group(1) not in island_f and m.group(1) not in ("add_child","get_tree","talk"):
            errs.append(f"{rel}: isl.{m.group(1)}() not in island.gd")
    for m in re.finditer(r"\bisl\.hud\.(\w+)\(", t):
        if m.group(1) not in inherited("Hud") and m.group(1) not in ("add_child","get_tree","queue_free"):
            errs.append(f"{rel}: hud.{m.group(1)}() not in Hud")
# 3. := from Variant-returning
pat = re.compile(r"^\s*var \w+ := .*(\.get\(|\.pop_|\bget_meta\(|\.values\(\)\[|\[\"[^\]]+\"\])")
for p, t in src.items():
    rel = os.path.relpath(p, root)
    for i, line in enumerate(t.split("\n"), 1):
        if pat.match(line) and not re.search(r"(float|int|str|String|Vector\d|Color|bool)\(", line) and " as " not in line:
            warns.append(f"{rel}:{i} ':=' on possibly-Variant expr: {line.strip()[:90]}")
# 4. % format counts
for p, t in src.items():
    rel = os.path.relpath(p, root)
    for i, line in enumerate(t.split("\n"), 1):
        for m in re.finditer(r'L\("((?:\\.|[^"\\])*)",\s*"((?:\\.|[^"\\])*)"\)\s*%\s*(\[[^\]]*\]|[\w\.\(\)]+)', line):
            en, ar, arg = m.groups()
            ne = len(re.findall(r"%[sdf]", en)); na = len(re.findall(r"%[sdf]", ar))
            nargs = arg.count(",") + 1 if arg.startswith("[") else 1
            if ne != na or (ne != nargs and not arg.startswith("[") and ne > 1) or (arg.startswith("[") and ne != nargs and nargs <= 4 and "(" not in arg):
                errs.append(f"{rel}:{i} format mismatch en={ne} ar={na} args={nargs}")
# 5. connect() to unknown methods
for p, t in src.items():
    rel = os.path.relpath(p, root)
    for m in re.finditer(r"\.connect\((\w+)\)", t):
        if m.group(1) not in all_funcs and m.group(1) not in ("queue_free",):
            errs.append(f"{rel}: connect({m.group(1)}) target not found")
print(f"{len(files)} files; {len(errs)} errors; {len(warns)} warnings")
for e in errs: print("ERR ", e)
for w in warns: print("WARN", w)
sys.exit(1 if errs else 0)
