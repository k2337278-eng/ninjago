extends SceneTree
## Run (needs Godot 4.3+):  godot --headless --path . -s tests/test_data.gd
## NOT YET EXECUTED in the authoring environment (no Godot available there).

func _init() -> void:
	var fails := 0
	for id in CharacterDB.ORDER:
		var d: Dictionary = CharacterDB.DATA[id]
		for k in ["name", "element", "suit", "hp", "speed", "light", "heavy", "poise", "ability"]:
			if not d.has(k):
				print("FAIL missing %s.%s" % [id, k])
				fails += 1
		var ab: Dictionary = d["ability"]
		for k in ["name", "kind", "damage", "cooldown", "color"]:
			if not ab.has(k):
				print("FAIL missing %s.ability.%s" % [id, k])
				fails += 1
		if ab.get("kind", "") == "projectile":
			for k in ["range", "speed", "radius"]:
				if not ab.has(k):
					print("FAIL projectile %s missing %s" % [id, k])
					fails += 1
		if ab.get("kind", "") == "aoe" and not ab.has("radius"):
			print("FAIL aoe %s missing radius" % id)
			fails += 1
	print("character data checks done, failures: %d" % fails)
	quit(1 if fails > 0 else 0)
