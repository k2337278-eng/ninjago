#!/usr/bin/env python3
"""Independent GLB reader/validator + tiny software renderer (CPU skinning).
Parses a .glb from scratch, validates accessors/skins/animations, renders poses to PNG.
Usage: preview_glb.py minifig.glb out.png"""
import json, struct, sys, math
import numpy as np
from PIL import Image, ImageDraw

def load(path):
    d = open(path, "rb").read()
    magic, ver, total = struct.unpack("<4sII", d[:12]); assert magic == b"glTF" and ver == 2 and total == len(d), "bad header"
    off = 12; js = None; binb = b""
    while off < len(d):
        ln, ty = struct.unpack("<II", d[off:off+8]); chunk = d[off+8:off+8+ln]; off += 8 + ln
        assert ln % 4 == 0, "chunk not 4-aligned"
        if ty == 0x4E4F534A: js = json.loads(chunk)
        elif ty == 0x004E4942: binb = chunk
    return js, binb
CT = {5120: np.int8, 5121: np.uint8, 5122: np.int16, 5123: np.uint16, 5125: np.uint32, 5126: np.float32}
NC = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT4": 16}
def read(js, binb, ai):
    a = js["accessors"][ai]; v = js["bufferViews"][a["bufferView"]]
    dt = np.dtype(CT[a["componentType"]]); n = NC[a["type"]]
    assert v["byteOffset"] % 4 == 0, "bufferView offset not aligned"
    arr = np.frombuffer(binb, dt, a["count"] * n, v["byteOffset"] + a.get("byteOffset", 0))
    assert v["byteOffset"] + a["count"] * n * dt.itemsize <= len(binb), "accessor overruns buffer"
    return arr.reshape(a["count"], n) if n > 1 else arr
def validate(js, binb):
    errs = []
    assert js["asset"]["version"] == "2.0"
    for i, a in enumerate(js["accessors"]):
        arr = read(js, binb, i)
        if "min" in a and not np.allclose(np.atleast_1d(arr.min(axis=0)), a["min"], atol=1e-5): errs.append(f"acc{i} min mismatch")
        if "max" in a and not np.allclose(np.atleast_1d(arr.max(axis=0)), a["max"], atol=1e-5): errs.append(f"acc{i} max mismatch")
        if not np.all(np.isfinite(arr.astype(float))): errs.append(f"acc{i} non-finite")
    nn = len(js["nodes"])
    for m in js["meshes"]:
        for p in m["primitives"]:
            nv = js["accessors"][p["attributes"]["POSITION"]]["count"]
            idx = read(js, binb, p["indices"])
            if idx.max() >= nv: errs.append(f"{m['name']}: index out of range")
            if len(idx) % 3: errs.append(f"{m['name']}: indices not multiple of 3")
            for k, ai in p["attributes"].items():
                if js["accessors"][ai]["count"] != nv: errs.append(f"{m['name']}.{k} count mismatch")
            if "JOINTS_0" in p["attributes"]:
                nj = len(js["skins"][0]["joints"]); 
                if read(js, binb, p["attributes"]["JOINTS_0"]).max() >= nj: errs.append(f"{m['name']} joint idx out of range")
                w = read(js, binb, p["attributes"]["WEIGHTS_0"]); 
                if not np.allclose(w.sum(axis=1), 1.0, atol=1e-4): errs.append(f"{m['name']} weights not normalised")
    for s in js.get("skins", []):
        for j in s["joints"]: assert j < nn
        assert len(read(js, binb, s["inverseBindMatrices"])) == len(s["joints"])
    for an in js.get("animations", []):
        for ch in an["channels"]:
            sm = an["samplers"][ch["sampler"]]; t = read(js, binb, sm["input"]); o = read(js, binb, sm["output"])
            if len(t) != len(o): errs.append(f"anim {an['name']} len mismatch")
            if not np.all(np.diff(t) > 0): errs.append(f"anim {an['name']} times not increasing")
            if ch["target"]["path"] == "rotation" and not np.allclose(np.linalg.norm(o, axis=1), 1.0, atol=1e-4): errs.append(f"anim {an['name']} quaternion not unit")
    return errs

def quat_to_mat(q):
    x, y, z, w = q
    return np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)], [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)], [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])
def sample(t, times, vals):
    if t <= times[0]: return vals[0]
    if t >= times[-1]: return vals[-1]
    i = np.searchsorted(times, t) - 1; f = (t - times[i]) / (times[i+1] - times[i])
    r = vals[i] * (1 - f) + vals[i+1] * f
    return r / np.linalg.norm(r) if r.shape[0] == 4 else r
def skin_vertices(js, binb, anim, t):
    nodes = js["nodes"]; skin = js["skins"][0]; ibm = read(js, binb, skin["inverseBindMatrices"])
    tr = {i: np.array(n.get("translation", [0, 0, 0]), float) for i, n in enumerate(nodes)}
    ro = {i: np.array(n.get("rotation", [0, 0, 0, 1]), float) for i, n in enumerate(nodes)}
    if anim is not None:
        a = [x for x in js["animations"] if x["name"] == anim][0]
        for ch in a["channels"]:
            sm = a["samplers"][ch["sampler"]]; tm = read(js, binb, sm["input"]); v = read(js, binb, sm["output"]).astype(float)
            val = sample(t, tm, v); (ro if ch["target"]["path"] == "rotation" else tr)[ch["target"]["node"]] = val
    par = {}
    for i, n in enumerate(nodes):
        for c in n.get("children", []): par[c] = i
    world = {}
    def W(i):
        if i in world: return world[i]
        M = np.eye(4); M[:3, :3] = quat_to_mat(ro[i]); M[:3, 3] = tr[i]
        world[i] = (W(par[i]) @ M) if i in par else M; return world[i]
    out = []
    for ni, n in enumerate(nodes):
        if "mesh" not in n: continue
        for p in js["meshes"][n["mesh"]]["primitives"]:
            P = read(js, binb, p["attributes"]["POSITION"]).astype(float); J = read(js, binb, p["attributes"]["JOINTS_0"])[:, 0]
            idx = read(js, binb, p["indices"]).astype(int).reshape(-1, 3); col = js["materials"][p["material"]]["pbrMetallicRoughness"]["baseColorFactor"][:3]
            Pn = np.zeros_like(P)
            for ji, jn in enumerate(skin["joints"]):
                m = J == ji
                if m.any():
                    S = W(jn) @ ibm[ji].reshape(4, 4).T; Pn[m] = (np.c_[P[m], np.ones(m.sum())] @ S.T)[:, :3]
            out.append((js["nodes"][ni]["name"], Pn, idx, col))
    return out
def render(tris_sets, size=(200, 260), yaw=0.55, hide=()):
    img = Image.new("RGB", size, (30, 34, 48)); dr = ImageDraw.Draw(img)
    R = np.array([[math.cos(yaw), 0, -math.sin(yaw)], [0, 1, 0], [math.sin(yaw), 0, math.cos(yaw)]])
    items = []
    for name, P, idx, col in tris_sets:
        if name in hide: continue
        Q = P @ R.T
        for t in idx:
            a, b, c = Q[t]; n = np.cross(b - a, c - a); ln = np.linalg.norm(n)
            if ln < 1e-12: continue
            n /= ln
            items.append((np.mean([a[2], b[2], c[2]]), (a, b, c), n, col))
    items.sort(key=lambda x: -x[0])   # camera at -z looking +z: far (large z) first
    sc = size[1] / 2.1
    for _, tri, n, col in items:
        if n[2] > 0.05: continue      # backface (normal pointing away from camera at -z)
        shade = 0.35 + 0.65 * max(0.0, np.dot(n, np.array([0.3, 0.6, -0.75])))
        pts = [(size[0]/2 - p[0]*sc, size[1] - 12 - p[1]*sc) for p in tri]
        dr.polygon(pts, fill=tuple(int(min(1, c*shade) * 255) for c in col))
    return img
if __name__ == "__main__":
    js, binb = load(sys.argv[1]); errs = validate(js, binb)
    print("VALIDATION:", "OK" if not errs else errs, "| nodes", len(js["nodes"]), "meshes", len(js["meshes"]), "anims", len(js.get("animations", [])))
    if len(sys.argv) > 2 and "animations" in js:
        shots = [("idle", 0.5), ("walk", 0.2), ("run", 0.14), ("jump", 0.7), ("light1", 0.55), ("light3", 0.7), ("heavy", 0.3), ("cast", 0.4),
                 ("dodge", 0.5), ("block", 0.5), ("spin", 0.1), ("climb", 0.2)]
        W, H = 200, 260; sheet = Image.new("RGB", (W * 6, H * 2))
        for i, (a, k) in enumerate(shots):
            D = max(js["animations"][[x["name"] for x in js["animations"]].index(a)]["samplers"], key=lambda s: 0)
            tm = read(js, binb, js["animations"][[x["name"] for x in js["animations"]].index(a)]["samplers"][0]["input"]); t = float(tm[-1]) * k
            sets = skin_vertices(js, binb, a, t); hide = ("head_bare", "opt_hair", "opt_hat", "opt_robe")
            im = render(sets, (W, H), hide=hide); ImageDraw.Draw(im).text((6, 6), a, fill=(255, 255, 255)); sheet.paste(im, ((i % 6) * W, (i // 6) * H))
        sheet.save(sys.argv[2]); print("saved", sys.argv[2])
